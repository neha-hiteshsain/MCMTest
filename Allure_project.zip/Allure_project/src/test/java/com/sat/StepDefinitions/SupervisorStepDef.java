package com.sat.StepDefinitions;

import java.awt.AWTException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.junit.Assume;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;


import com.sat.Pages.MCMviewAppLoginPage;
import com.sat.Pages.Mcm_AdminPage;
import com.sat.Pages.SupervisorPage;
import com.sat.config.ConfigFileReader;
import com.sat.testUtil.Testutil;
import com.sat.testUtil.Wait;
import com.sat.testbase.Assertions;
import com.sat.testbase.TestBase;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

	public class SupervisorStepDef {
	//public WebDriver driver;
	WebDriver driver = TestBase.getDriver();
	private MCMviewAppLoginPage MCMviewAppLogin = new MCMviewAppLoginPage(TestBase.getDriver());
	 Assertions assertion = new Assertions(driver);
	 private ConfigFileReader config = new ConfigFileReader();
	 private Mcm_AdminPage MCMadmin = new Mcm_AdminPage(TestBase.getDriver());
	 private SupervisorPage Superobj = new SupervisorPage(TestBase.getDriver());
	
	@Then ("user click on Tab {string} for selecting {string}")
	public void user_click_on_Tab_for(String Tabname,String Value) throws InterruptedException
	{
		Thread.sleep(2000);
		Superobj.clickRelatedTab(Tabname);
	}
	
	 @Then ("user click on dropdown for field {string} under status")
		 public void user_click_on_under_Status(String Dropdownval) throws InterruptedException
			{
				Thread.sleep(2000);
				Superobj.UserClickDropdownUnderStatus(Dropdownval);
			} 
	 @Then ("user verify {string} value exists")
	 public void user_verifies_value_exist(String value)
	 {
		Boolean fieldExistsOrNot =Superobj.fieldExistorNot(value);
		System.out.println("\u001B[32m"+fieldExistsOrNot+"\u001B[0m");
	 }
	
	 @Then ("user click on the {string} icon under {string}")
	 public void user_click_on_spyglass_icon_under_Add_schedule_lines(String icon,String tab) throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.ClickOnIcon(icon);
		 System.out.print("Clicked under tab: "+tab);
	 }
	 @Then ("user click on one of the SOR items")
	 public void user_click_on_SOR_item() throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.ClickOnSORItem();
		 
	 }
	 @Then ("user validate add schedule line text field value update")
	 public void user_validate_text_feild_value_for_Schedule_line() throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.UserValidateAddScheduleLineFieldDisplay();
	 }
	 @Then ("Validate the table row increased before adding schedule line")
	 public void user_validate_row_count_before_adding() throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.ValidateRowCountBefore();
	 }
	 @Then ("Validate the table row increased after adding schedule line")
	 public void user_validate_row_count_after_adding() throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.ValidateRowCountAfter();
	 }
	 @Then ("user select the recent form displayed under Completed Electrical Certificates")
	 public void user_select_the_last_row_in_form() throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.SelectLastRowForm();
	 }
	 @Then ("user select the recent JobNo under Domestic Fire Alarm Certificate")
	 public void user_select_the_recent_jobno_from_DomesticFireAlarm() throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.ClickJobNoDomesticFire();
	 }
	 @Then ("user select the recent JobNo under EIC")
	 public void user_select_the_recent_jobno_from_EIC() throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.ClickJobNoEIC();
	 }
	 @Then ("user select the recent JobNo under EIVR")
	 public void user_select_the_recent_jobno_from_EIVR() throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.ClickJobNoEIVR();
	 }
	 @Then ("user select the recent JobNo under EICR")
	 public void user_select_the_recent_jobno_from_EICR() throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.ClickJobNoEICR();
	 }
	 @Then ("user select the recent JobNo {string} under All")
	 public void user_select_the_recent_jobno_for_All(String JobNo) throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.ClickJobNoAll(JobNo);
	 }
	 @Then ("user fill the Review Note in form")
	 public void user_fill_review_note() throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.FillReviewNoteInForm();
	 }
	 @Then ("user navigate to {string} in form")
	 public void user_navigate_to_tablist_in_form(String tab) throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.ClickOnTablistInForm(tab);
	 }
	 @Then ("user click on check box under declaration in form")
	 public void click_on_declaration_chk_form() throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.ClickOnDeclaartionChkbox();
	 }
	 @Then ("user click on {string} on form")
	 public void click_on_btn_in_form(String name) throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.ClickOnBtnInForm(name);
	 }
	 @Then ("user fill the note as {string} on form name {string}")
	 public void click_fill_note_on_form(String val,String name) throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.FillNoteInForm(val,name);
	 }
	 @Then ("user click on the customer visible checkbox under document")
	 public void click_on_customer_visible_checkbox() throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.ClickOnChkBoxCustomerVisible();
	 }
	 @Then ("click on {string} under Jobs")
	 public void click_on_button_under_jobs(String Tabname) throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.ClickOnTabUnderJobs(Tabname);
	 }
	 @And ("user click on the Book icon under Date Due")
	 public void click_on_the_Book_icon() throws InterruptedException
	 {
		 Thread.sleep(1000);
		 Superobj.ClickOnBookIconUnderDate();
	 }
	  @And ("the user clicks on the plus icon in front of the folder {string}")
	  public void click_on_the_plus_icon_under_folder(String foldername) throws InterruptedException
		 {
			 Thread.sleep(1000);
			 Superobj.ClickOnPlusIconUnderFolder(foldername);
		 }
	  @Then ("user click on {string} of the file under {string}")
	  public void click_on_the_file_under_folder(String num,String foldername) throws InterruptedException, IOException
		 {
			 Thread.sleep(1000);
			 Superobj.ClickOnFileUnderFolder(num,foldername);
		 }
	}
	
	 
	
 
 

