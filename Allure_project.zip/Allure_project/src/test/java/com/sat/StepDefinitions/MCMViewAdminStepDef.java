package com.sat.StepDefinitions;

import java.awt.AWTException;
import java.util.List;
import java.util.Map;

import org.junit.Assume;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;


import com.sat.Pages.MCMviewAppLoginPage;
import com.sat.Pages.Mcm_AdminPage;
import com.sat.config.ConfigFileReader;
import com.sat.testUtil.Wait;
import com.sat.testbase.Assertions;
import com.sat.testbase.TestBase;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

	public class MCMViewAdminStepDef {
	//public WebDriver driver;
	WebDriver driver = TestBase.getDriver();
	private MCMviewAppLoginPage MCMviewAppLogin = new MCMviewAppLoginPage(TestBase.getDriver());
	 Assertions assertion = new Assertions(driver);
	 private ConfigFileReader config = new ConfigFileReader();
	 private Mcm_AdminPage MCMadmin = new Mcm_AdminPage(TestBase.getDriver());
	 

		@Then ("user Enter a {string} as {string}")
			public void user_enter_email_id(String string, String value)
				{
					try {
						Thread.sleep(3000);
						driver.findElement(By.xpath("//*[@id='"+ string+"']")).sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
						//driver.findElement(By.xpath("//*[@id='"+ string+"']")).sendKeys(Keys.BACK_SPACE);
						driver.findElement(By.xpath("//*[@id='"+ string +"']")).sendKeys(value);
					} catch(Exception e) {
						e.printStackTrace();
					}
					}
		 @Then ("user click on Generate to generate the password")
		 public void user_click_on_generate_for_password() throws InterruptedException
		 {
			 Thread.sleep(3000);
			 MCMadmin.clickOnGeneratePassword();
		 }
		 
		 @Then ("user validate user account pre-exist check {string}")
		 public void user_validate_pre_exist_check(String string)
		 {
			 assertion.CheckAssertionTrue(driver.findElement(By.xpath("//*[@class='validation-summary-errors']")).getAttribute("textContent").contains(string), string);
		 }
		 		
		 @Then ("generate the random email ID {string}")
		 public void user_generate_random_email_address(String string)
		 {
			 MCMadmin.GenerateRandomEmailId(string); 
		 }
		 @Then ("user click {string} under {string}")
		 public void user_click_under_related_tab_for_selecting_role(String ID,String string) throws InterruptedException
		 {
			 Thread.sleep(2000);
			
			 MCMadmin.ClickUnderTabforSelectingVal(ID,string); 
		 }
		@And ("user select {string} from Sites")
		 public void user_select_from_Sites(String option) throws InterruptedException
		 {
			try {
			 Thread.sleep(2000);
			 MCMadmin.SelectOptionUnderSites(option); 
			}
			catch(Exception e) {
				System.out.println("Exception :" +e+ "has occured");
			}
		 }
		 @Then ("user click on Menu button user log-in")
		 public void user_click_on_menu_button_user_log_in()
		 {
			 try {
				 Thread.sleep(2000);
				 MCMadmin.ClickOnUserMenuIcon(); 
				}
				catch(Exception e) {
					System.out.println("Exception :" +e+ "has occured");
				}
		 }
		 @Then ("user enter random email generated as {string}")
		 public void user_enter_random_email_generated(String string)
		 {
			 try {
				 Thread.sleep(2000);
				 MCMadmin.EnterRandomEmailId(string); 
				}
				catch(Exception e) {
					System.out.println("Exception :" +e+ "has occured");
				}
		 }
		@ Then ("user select the email id displayed for user")
		public void user_select_email_id_displayed()
		{
			MCMadmin.UserSelectEmailDisplayed(); 
		}
		@And ("user validate correct role,permission and sites are selected for id")
		public void user_validate_correct_value_are_selected(DataTable dataTable)
		{
			try {
			MCMadmin.ValidateCorrectValueSelected(dataTable); 
			}
			catch(Exception e)
			{
				System.out.println("Exception : " +e + "has occurred");
			}
		}
		 
		@Then ("user click on {string} under user")
		public void user_click_on_btn_under_user(String val)
		{
			try {
			MCMadmin.UserClickUnderUserbtn(val); 
			}
			catch(Exception e)
			{
				System.out.println("Exception : " +e + "has occurred");
			}
		}
		 @Then ("user click on {string} under user for {string}")
		 public void user_click_on_btn_under_user_for_(String val,String classname)
			{
				try {
				MCMadmin.UserClickUnderUserbtnforClass(val,classname); 
				}
				catch(Exception e)
				{
					System.out.println("Exception : " +e + "has occurred");
				}
			}
		 @Then ("user click on Copy User")
		 public void user_click_on_copy_user()
			{
				try {
				MCMadmin.UserClickOnCopyUser(); 
				}
				catch(Exception e)
				{
					System.out.println("Exception : " +e + "has occurred");
				}
			}
		@Then ("user validate alert message is display for {string}")
		public void user_validate_alert_message_displayed(String value)
		{
			MCMadmin.verifyAlertField(value); 
		}
		 @Then ("user generate the unique Account number for {string}")
		 public void user_generate_random_account_number(String Accno)
		 {
			 try {
				 Thread.sleep(2000);
				 MCMadmin.GenerateRandomAccountNumber(Accno); 
				}
				catch(Exception e) {
					System.out.println("Exception :" +e+ "has occured");
				}
		 }
		 @Then ("user click on {string} under button {string}")
		 public void user_click_on_btn_under_user_under_button(String val,String classname)
			{
				try {
					
				MCMadmin.UserClickUnderSitesbtn(classname); 
				System.out.println("Clicked on "+val);
				}
				catch(Exception e)
				{
					System.out.println("Exception : " +e + "has occurred");
				}
			}
		 @Then ("user click on dropdown under Property Allocation PopUp {string}")
		 public void user_click_on_dropdown_under_Property_Allocation(String classname)
			{
				try {
				MCMadmin.UserClickUnderPropertyAllocation(classname); 
				}
				catch(Exception e)
				{
					System.out.println("Exception : " +e + "has occurred");
				}
			}
		 @Then ("user select the {string} under the tab {string}")
		 public void user_click_on_row_under_tab(String val,String classname)
			{
				try {
					
				MCMadmin.UserClickUnderTab(classname); 
				//System.out.println("Clicked on "+val);
				}
				catch(Exception e)
				{
					System.out.println("Exception : " +e + "has occurred");
				}
			}
		 @Then ("user Scroll down")
		 public void user_Scroll_down()
			{
			 MCMviewAppLogin.scrolldown();
			}
		  @Then ("user click the contract under Sites")
		  public void user_Click_on_contract_under_Site() throws InterruptedException
			{
			  MCMadmin.UserClickContractUnderSite(); 
			} 
		  @Then ("validate the Contract is deleted or added from site")
		  public void user_validate_contract() throws InterruptedException
			{
			  MCMadmin.UserValidateContract(); 
			} 
		  @And ("validate Completed Request pop-up page")
		  public void user_validate_Complete_Request_page()
		  {
			  MCMadmin.UserValidateCompletRequestFieldDisplay(); 
		  }
	}
	 
	
 
 

