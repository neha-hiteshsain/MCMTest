package com.sat.TestRunner;

import org.openqa.selenium.WebDriver;
import org.slf4j.helpers.Util;
import org.testng.annotations.DataProvider;

import com.sat.testUtil.Testutil;
import com.sat.testbase.TestBase;

import io.cucumber.java.After;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;



//	@RunWith(Cucumber.class)
	@CucumberOptions(
			features={"src/test/resources/com.sat.Features"},
			glue={"com.sat.StepDefinitions","com.sat.AppHooks"},
			monochrome=true,
			plugin = {"pretty","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"},
			//plugin={"pretty","json:target/cucumber.json","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:","html:target/cucumber-reports/report.html"},
			//tags=("@AdminTool_And_Click&Meet"))
			//tags ={"@ResalRegistration or @ResalForgotpassword or @RegisteringItem"})//@ResalForgotpassword //@RegisteringItem //@ResalRegistration
	tags= "@TC_173195_173201_MCMView_MK_Upload_photo_Customer_visible_&_Not_Customer_visible or \r \n"+
			"@TC_173196_MCMView_Amend_SOR_qty_Increase_in_quantity_will_be_reflected_in_total-pricing-error-correction or \r \n" +
			"@TC_173199_MCMView_Address_Search-House_No or \r \n" +
			"@TC_173202_173203_MCMView_MK_Add_an_SOR_with_a_qty_of_21_and_a_note_&_a_qty_of_43_and_an_adjustment or \r \n" +
			"@TC_173204_MCMView_MK_Add_2_SOR's_with_a_qty_of_1_and_6 or \r \n" +
			"@TC_173205_MCMView_Amend_SOR_qty_Increase_in_quantity_will_be_reflected_in_total-Varation_required or \r \n" +
			"@TC_173206_173207_MCMView_Amend_SOR_qty_decrease_in_quantity_will_be_reflected_in_total-Added_in_error or \r \n" +
			"@TC_173208_173209_MCMView_View_address_comments_&_View_Asbestos_details or \r \n" +
			"@TC_173211_173214_173215_MCMView_Update_Priority_and_Change_Job_Type_and_Update_Tel_No or \r \n" +
			"@TC_71624_MCMView_MK_Audit_Log_Search_by_Entry_types or \r \n" +
			"@TC_71625_MCMView_MK_View_elec_certs_and_check_audit or \r \n" +
			"@TC_71628_MCMView_MK_Update_status_from_3-2_and_check_Audit or \r \n" +
			"@TC_71632_MCMView_MK_Audit_Live_Search" 
			
		
			)
	
	public class SuperUserRunner extends AbstractTestNGCucumberTests{
		//@Override
	      
	   //   @DataProvider(parallel = true) 
	   // public Object[][] scenarios() { 
			// return super.scenarios();
		 
	//}
	}
		/*
		@After
		public void afterScenario(Scenario scenario) {
			TestBase testbase = new TestBase();
			WebDriver driver = TestBase.getDriver();
			byte[] screenshot= Testutil.takesscreenshot(driver);
			scenario.attach( "image/png", scenario.getName());
	}
	}
	*/
		/*@BeforeStep
		public void beforeStep() {
		}

		@AfterStep
		public void afterStep() {
		}

		@Before
		public void beforeScenario() {
		}

		@After
		public void afterScenario(Scenario scenario) {
//			scenario.attach(Util.takeScreenShot(), "image/png", scenario.getName());
		}*/
	
	
	//"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
//	import cucumber.api.CucumberOptions;
//	import cucumber.api.testng.AbstractTestNGCucumberTests;
//	@CucumberOptions(features="src/test/resources/features",glue="stepDefinitions",tags="@Test01",plugin= {"pretty", "html:target/cucumber-reports" },monochrome=true)

//public class TestRunner {
//    private TestNGCucumberRunner testNGCucumberRunner;
// 
//    @BeforeClass(alwaysRun = true)
//    public void setUpClass() throws Exception {
//        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
//    }
// 
//    @Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
//    public void feature(CucumberFeatureWrapper cucumberFeature) {
//        testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
//    }
// 
//    @DataProvider
//    public Object[][] scenarios() {
//        return testNGCucumberRunner.provideScenarios();
//    }
// 
//    @AfterClass(alwaysRun = true)
//    public void tearDownClass() throws Exception {
//        testNGCucumberRunner.finish();
//    }
//}	
//	
//		
//	
