package com.sat.TestRunner;

import org.openqa.selenium.WebDriver;
import org.slf4j.helpers.Util;
import org.testng.annotations.DataProvider;

import com.sat.testUtil.Testutil;
import com.sat.testbase.TestBase;

import io.cucumber.java.After;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;



//	@RunWith(Cucumber.class)
	@CucumberOptions(
			features={"src/test/resources/com.sat.Features"},
			glue={"com.sat.StepDefinitions","com.sat.AppHooks"},
			monochrome=true,
			plugin = {"pretty","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"},
			//plugin={"pretty","json:target/cucumber.json","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:","html:target/cucumber-reports/report.html"},
			//tags=("@AdminTool_And_Click&Meet"))
			//tags ={"@ResalRegistration or @ResalForgotpassword or @RegisteringItem"})//@ResalForgotpassword //@RegisteringItem //@ResalRegistration
	tags= "@71769_MCMView_MK_Rejecting_a_No_Cert_Electrical_Certificat or \r \n"+
			"@TC_150713_MCMView_MK_Move_from_Branch_query_to_Authorised or \r \n" +
			"@TC_150735_MCMView_MK_Preview_and_Download_an_existing_Workticket_in_Job  or \r \n" +
			"@TC_171335_171338_171339_171340_MCMView_MK_Add_an_SOR_with_a_qty_of_1_and_a_note_and_a_qty_8_and_SOR_with_qty_1_and_cancel_without_saving or \r \n" +
			"@TC_171363_MCMView_MK_Audit_Live_Search or \r \n" +
			"@TC_171379_MCMView_MK_Audit-Filter_by_entry_type-original_value or \r \n" +
			"@TC_171395_171397_MCMView_MK_Amend_SOR_qty_decrease_&_increase_in_total-Varation or \r \n" +
			"@TC_171400_171399_MCMView_MK_View_Asbestos_details_View_address_comment or \r \n" +
			"@TC_171408_MCMView_MK_Upload_photo-Customer_visible or \r \n" +
			"@TC_61658_71765:Added_in_error_&_Audit_reason_other-free_text_field_displayed or \r \n" +
			"@TC_63063_MCMView_Address_Lookup-Live_Search or \r \n" +
			"@TC_71757_MCMView_MK_Update_status_from_1-0_and_check_Audit" 
			
		
			)
	
	public class Supervisor_with_Admin_and_no_veco_role extends AbstractTestNGCucumberTests{
		//@Override
	      
	   //   @DataProvider(parallel = true) 
	   // public Object[][] scenarios() { 
			// return super.scenarios();
		 
	//}
	}
		/*
		@After
		public void afterScenario(Scenario scenario) {
			TestBase testbase = new TestBase();
			WebDriver driver = TestBase.getDriver();
			byte[] screenshot= Testutil.takesscreenshot(driver);
			scenario.attach( "image/png", scenario.getName());
	}
	}
	*/
		/*@BeforeStep
		public void beforeStep() {
		}

		@AfterStep
		public void afterStep() {
		}

		@Before
		public void beforeScenario() {
		}

		@After
		public void afterScenario(Scenario scenario) {
//			scenario.attach(Util.takeScreenShot(), "image/png", scenario.getName());
		}*/
	
	
	//"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
//	import cucumber.api.CucumberOptions;
//	import cucumber.api.testng.AbstractTestNGCucumberTests;
//	@CucumberOptions(features="src/test/resources/features",glue="stepDefinitions",tags="@Test01",plugin= {"pretty", "html:target/cucumber-reports" },monochrome=true)

//public class TestRunner {
//    private TestNGCucumberRunner testNGCucumberRunner;
// 
//    @BeforeClass(alwaysRun = true)
//    public void setUpClass() throws Exception {
//        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
//    }
// 
//    @Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
//    public void feature(CucumberFeatureWrapper cucumberFeature) {
//        testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
//    }
// 
//    @DataProvider
//    public Object[][] scenarios() {
//        return testNGCucumberRunner.provideScenarios();
//    }
// 
//    @AfterClass(alwaysRun = true)
//    public void tearDownClass() throws Exception {
//        testNGCucumberRunner.finish();
//    }
//}	
//	
//		
//	
