package com.sat.TestRunner;

import org.openqa.selenium.WebDriver;
import org.slf4j.helpers.Util;
import org.testng.annotations.DataProvider;

import com.sat.testUtil.Testutil;
import com.sat.testbase.TestBase;

import io.cucumber.java.After;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;



//	@RunWith(Cucumber.class)
	@CucumberOptions(
			features={"src/test/resources/com.sat.Features"},
			glue={"com.sat.StepDefinitions","com.sat.AppHooks"},
			monochrome=true,
			plugin = {"pretty","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"},
			//plugin={"pretty","json:target/cucumber.json","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:","html:target/cucumber-reports/report.html"},
			//tags=("@AdminTool_And_Click&Meet"))
			//tags ={"@ResalRegistration or @ResalForgotpassword or @RegisteringItem"})//@ResalForgotpassword //@RegisteringItem //@ResalRegistration
	tags= "@171360_61432_MCMView_MK_Add_2_SOR_with_a_qty_of_1_and_5 or \r \n"+
			"@TC_150712_MCMView_MK_Audit_Live_Search or \r \n" +
			"@TC_150727_MCMView_MK_Move_from_Completed_today_to_Survey_Required or \r \n" +
			"@TC_150738_MCMView_MK_Update_status_from_0-2_and_check_Audit or \r \n" +
			"@TC_150744_MCMView_MK_Add_New_Routine_Job-Address_Level or \r \n" +
			"@TC_171218_173213_173216_MCMView_Update_Priority_and_Change_Job_Type-Done_Add_Tel_No_Edit_Email or \r \n" +
			"@TC_171219_MCMView_Address_Search-House_No-Dones or \r \n" +
			"@TC_171358_171359_MCMView_MK_Add_an_SOR_with_a_qty_of_11_and_17 or \r \n" +
			"@TC_171398_171396_MCMView_Amend_SOR_qty_decrease_in_quantity_will_be_reflected_in_total-Added_in_error or \r \n" +
			"@TC_171401_171402_MCMView__View_address_comments_View_Asbestos_details or \r \n" +
			"@TC_63061_MCMView_MK_Update_status_from_2-1 or \r \n" +
			"@TC_71725_171405_171221_MCMView_MK_Upload_photo-Customer_visible or \r \n" +
			"@TC_71772_171394_MCMView_Amend_SOR_qty_Increase_in_quantity_will_be_reflected" 
			
		
			)
	
	public class Supervisor_no_veco_role extends AbstractTestNGCucumberTests{
		//@Override
	      
	   //   @DataProvider(parallel = true) 
	   // public Object[][] scenarios() { 
			// return super.scenarios();
		 
	//}
	}
		/*
		@After
		public void afterScenario(Scenario scenario) {
			TestBase testbase = new TestBase();
			WebDriver driver = TestBase.getDriver();
			byte[] screenshot= Testutil.takesscreenshot(driver);
			scenario.attach( "image/png", scenario.getName());
	}
	}
	*/
		/*@BeforeStep
		public void beforeStep() {
		}

		@AfterStep
		public void afterStep() {
		}

		@Before
		public void beforeScenario() {
		}

		@After
		public void afterScenario(Scenario scenario) {
//			scenario.attach(Util.takeScreenShot(), "image/png", scenario.getName());
		}*/
	
	
	//"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
//	import cucumber.api.CucumberOptions;
//	import cucumber.api.testng.AbstractTestNGCucumberTests;
//	@CucumberOptions(features="src/test/resources/features",glue="stepDefinitions",tags="@Test01",plugin= {"pretty", "html:target/cucumber-reports" },monochrome=true)

//public class TestRunner {
//    private TestNGCucumberRunner testNGCucumberRunner;
// 
//    @BeforeClass(alwaysRun = true)
//    public void setUpClass() throws Exception {
//        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
//    }
// 
//    @Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
//    public void feature(CucumberFeatureWrapper cucumberFeature) {
//        testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
//    }
// 
//    @DataProvider
//    public Object[][] scenarios() {
//        return testNGCucumberRunner.provideScenarios();
//    }
// 
//    @AfterClass(alwaysRun = true)
//    public void tearDownClass() throws Exception {
//        testNGCucumberRunner.finish();
//    }
//}	
//	
//		
//	
