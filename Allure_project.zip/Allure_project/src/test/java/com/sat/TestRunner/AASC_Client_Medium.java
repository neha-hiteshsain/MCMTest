package com.sat.TestRunner;

import org.openqa.selenium.WebDriver;
import org.slf4j.helpers.Util;
import org.testng.annotations.DataProvider;

import com.sat.testUtil.Testutil;
import com.sat.testbase.TestBase;

import io.cucumber.java.After;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;



//	@RunWith(Cucumber.class)
	@CucumberOptions(
			features={"src/test/resources/com.sat.Features"},
			glue={"com.sat.StepDefinitions","com.sat.AppHooks"},
			monochrome=true,
			plugin = {"pretty","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"},
			//plugin={"pretty","json:target/cucumber.json","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:","html:target/cucumber-reports/report.html"},
	tags= 	"@162240_AASC_Client_No_option_to_Edit_Service_user or \r \n"+
			"@162244_162246_162248_162249_AASC_Client_Address_Page-Cant_edit_alarm_details_&_Cant_edit_Key_log_&_Cant_Add_a_Key_&_Cant_Add_a_Key or \r \n" +
			"@162305_AASC_Client_Prop_Notes_Complete_a_Live_search_on_Subtype or \r \n" +
			"@162312_162313_162314_AASC_Client_No_option_to_add_Risk_assesment&_No_option_to_edit_risk_assessment or \r \n" +
			"@162324_162325_162334_AASC_Client_Prop_Complete_a_Live_search_on_note_contentAASC_&_Client_Property_Page-There_is_no_option_to_edit_Property_sections or \r \n" +
			"@162336_AASC_Client_Cant_edit_an_existing_complaint or \r \n" +
			"@173435_AASC_Client_Cannot_see_the_Tasks_panel_on_address_page or \r \n" +
			"@TC_162309_162342_AASC_Client_View_Inactive_Risks or \r \n" +
			"@TC_162329_AAS_Client_View_existing_note or \r \n" +
			"@TC_162331_AASC_Client_Can_view_an_existing_Incident or \r \n" +
			"@TC_162335_162341_AASC_Client_Address_Page-Cant_edit_Keys_Cant_Add_alarm_details or \r \n" +
			"@TC_162337_AASC_Client_No_option_to_Add_risk or \r \n" +
			"@TC_162343_AASC_Client_Prev_Inspections_Change_from_10_to_50_items_per_page or \r \n" +
			"@TC_162427_AASC_Client_No_option_to_end_or_update_a_Tenancy or \r \n" +
			"@TC_162465_AASC_Client_Address_Page-View_rooms or \r \n" +
			"@TC_162474_162475_162476_173437_AASC_Client_There_is_no_option_to_select_Task_Dashboard&_Appointment_Diary&_Add_Address" 
			
		
			)
	
	public class AASC_Client_Medium extends AbstractTestNGCucumberTests{
		//@Override
	      
	    //  @DataProvider(parallel = true) 
	   // public Object[][] scenarios() { 
		// return super.scenarios();
		 
	//}
	}
		/*
		@After
		public void afterScenario(Scenario scenario) {
			TestBase testbase = new TestBase();
			WebDriver driver = TestBase.getDriver();
			byte[] screenshot= Testutil.takesscreenshot(driver);
			scenario.attach( "image/png", scenario.getName());
	}
	}
	*/
		/*@BeforeStep
		public void beforeStep() {
		}

		@AfterStep
		public void afterStep() {
		}

		@Before
		public void beforeScenario() {
		}

		@After
		public void afterScenario(Scenario scenario) {
//			scenario.attach(Util.takeScreenShot(), "image/png", scenario.getName());
		}*/
	
	
	//"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
//	import cucumber.api.CucumberOptions;
//	import cucumber.api.testng.AbstractTestNGCucumberTests;
//	@CucumberOptions(features="src/test/resources/features",glue="stepDefinitions",tags="@Test01",plugin= {"pretty", "html:target/cucumber-reports" },monochrome=true)

//public class TestRunner {
//    private TestNGCucumberRunner testNGCucumberRunner;
// 
//    @BeforeClass(alwaysRun = true)
//    public void setUpClass() throws Exception {
//        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
//    }
// 
//    @Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
//    public void feature(CucumberFeatureWrapper cucumberFeature) {
//        testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
//    }
// 
//    @DataProvider
//    public Object[][] scenarios() {
//        return testNGCucumberRunner.provideScenarios();
//    }
// 
//    @AfterClass(alwaysRun = true)
//    public void tearDownClass() throws Exception {
//        testNGCucumberRunner.finish();
//    }
//}	
//	
//		
//	
