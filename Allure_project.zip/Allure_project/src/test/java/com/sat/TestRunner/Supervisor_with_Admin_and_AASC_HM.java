package com.sat.TestRunner;

import org.openqa.selenium.WebDriver;
import org.slf4j.helpers.Util;
import org.testng.annotations.DataProvider;

import com.sat.testUtil.Testutil;
import com.sat.testbase.TestBase;

import io.cucumber.java.After;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;



//	@RunWith(Cucumber.class)
	@CucumberOptions(
			features={"src/test/resources/com.sat.Features"},
			glue={"com.sat.StepDefinitions","com.sat.AppHooks"},
			monochrome=true,
			plugin = {"pretty","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"},
			//plugin={"pretty","json:target/cucumber.json","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:","html:target/cucumber-reports/report.html"},
			//tags=("@AdminTool_And_Click&Meet"))
			//tags ={"@ResalRegistration or @ResalForgotpassword or @RegisteringItem"})//@ResalForgotpassword //@RegisteringItem //@ResalRegistration
	tags= "@71769_MCMView_MK_Rejecting_a_No_Cert_Electrical_Certificat or \r \n"+
			"@TC_150735_MCMView_MK_Preview_and_Download_an_existing_Workticket_in_Job or \r \n" +
			"@TC_171222_MCMView_AASC_Update_Priority  or \r \n" +
			"@TC_171223_MCMView_AASC_Address_Search-House_No or \r \n" +
			"@TC_171225_171406_MCMView_AASC_Upload_photo-Not_Customer_visible or \r \n" +
			"@TC_171226_MCMView_AASC_Move_from_Completed_today_to_Survey_Required or \r \n" +
			"@TC_171227_MCMView_AASC_Add_New_Routine_Job-Address_Level or \r \n" +
			"@TC_171352_171353_MCMView_AASC_Add_an_SOR_with_a_qty_of_12_and_SOR_with_a_qty_of_1_and_2 or \r \n" +
			"@TC_171377_MCMView_AASC_Status_Search-140_Order_Approved or \r \n" +
			"@TC_171379_MCMView_MK_Audit-Filter_by_entry_type-original_value or \r \n" +
			"@TC_171381_171383_MCMView_AASC_Audit_Live_Search_and__Add_Audit_comment or \r \n" +
			"@TC_171395_171397_MCMView_MK_Amend_SOR_qty_decrease_&_increase_in_total-Varation or \r \n" +
			"@TC_171400_171399_MCMView_MK_View_Asbestos_details_View_address_comment or \r \n" +
			"@TC_171408_MCMView_MK_Upload_photo-Customer_visible or \r \n" +
			"@TC_61658_71765:Added_in_error_&_Audit_reason_other-free_text_field_displayed or \r \n" +
			"@TC_63063_MCMView_Address_Lookup-Live_Search" 
			
		
			)
	
	public class Supervisor_with_Admin_and_AASC_HM extends AbstractTestNGCucumberTests{
		//@Override
	      
	   //   @DataProvider(parallel = true) 
	   // public Object[][] scenarios() { 
			// return super.scenarios();
		 
	//}
	}
		/*
		@After
		public void afterScenario(Scenario scenario) {
			TestBase testbase = new TestBase();
			WebDriver driver = TestBase.getDriver();
			byte[] screenshot= Testutil.takesscreenshot(driver);
			scenario.attach( "image/png", scenario.getName());
	}
	}
	*/
		/*@BeforeStep
		public void beforeStep() {
		}

		@AfterStep
		public void afterStep() {
		}

		@Before
		public void beforeScenario() {
		}

		@After
		public void afterScenario(Scenario scenario) {
//			scenario.attach(Util.takeScreenShot(), "image/png", scenario.getName());
		}*/
	
	
	//"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
//	import cucumber.api.CucumberOptions;
//	import cucumber.api.testng.AbstractTestNGCucumberTests;
//	@CucumberOptions(features="src/test/resources/features",glue="stepDefinitions",tags="@Test01",plugin= {"pretty", "html:target/cucumber-reports" },monochrome=true)

//public class TestRunner {
//    private TestNGCucumberRunner testNGCucumberRunner;
// 
//    @BeforeClass(alwaysRun = true)
//    public void setUpClass() throws Exception {
//        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
//    }
// 
//    @Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
//    public void feature(CucumberFeatureWrapper cucumberFeature) {
//        testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
//    }
// 
//    @DataProvider
//    public Object[][] scenarios() {
//        return testNGCucumberRunner.provideScenarios();
//    }
// 
//    @AfterClass(alwaysRun = true)
//    public void tearDownClass() throws Exception {
//        testNGCucumberRunner.finish();
//    }
//}	
//	
//		
//	
