package com.sat.Pages;

import java.io.File;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Month;
import java.time.format.TextStyle;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.joda.time.LocalDate;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.sat.testUtil.Testutil;
import com.sat.testUtil.Wait;
import com.sat.testbase.Assertions;

import io.cucumber.datatable.DataTable;

public class KeysPage {
	private WebDriver driver;
	
	
	@FindBy(xpath = "//*[@role='button']//*[contains(@class,'mat-expansion-panel-header-title expansion_panel__header-title')]") 
	private WebElement Filteratask;
	
	@FindBy(xpath = "//*[contains(@class,'address-menu__container')]//*[contains(text(),'Jobs')]") 
	private WebElement objTabRelated;
	
	@FindBy(xpath = "//*[@aria-label='Open calendar']") 
	private WebElement gettingDate;
	
	WebElement Iconeditbtn;
	int iconCount;
	int documentCount;
	WebElement docnum;
	Testutil testutil = new Testutil();
	Wait waits = new Wait();
	Testutil util = new Testutil();
    Assertions assertion = new Assertions(driver);
   // private static String actualref;
    private static String expectedval;
	
    public KeysPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public boolean isClickable(WebElement ele) {
		boolean flag = true;
		try {
			new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.elementToBeClickable(ele));
			System.out.println("Element is clickable");
		} catch (Exception e) {
			System.out.println("Element isn't clickable");
			flag = false;
		}
		return flag;
	}
	
	
	
	//switching to the frame 
	public void switchToFrame() {
		driver.switchTo().frame("fullscreen-app-host");
	}
	public void ValidateKeyLogBookedOutBy(String Tab,String elementID, String val) throws InterruptedException {
	 	
	 	expectedval=val;
	 	System.out.println("\u001B[32mExpected value: .\u001B[0m"+expectedval);
	 		List<WebElement> cells = driver.findElements(By.xpath("//*[@title='"+Tab+"']//*[ contains(@class,'mat-cell cdk-cell mears-table__cell cdk-column-bookedOutBy mat-column-bookedOutBy ng-star-inserted')]"));
	 		System.out.println("\u001B[32mNumber of Row present in Table : .\u001B[0m"+cells.size());
	 		for(int i=0;i<=cells.size()-1;i++)
	 		{
	 			Thread.sleep(7000);
	 			String actualtext=cells.get(i).getText();
	 			
	 			System.out.println(actualtext);
	 			//System.out.println("\u001B[32mActual value.\u001B[0m"+actualtext);
	 			if(cells.get(i).getText().equals(expectedval))
	 			{
	 				System.out.println("\u001B[32mExpected value :.\u001B[0m"+expectedval+ "=="+"\u001B[32mActual Value.\u001B[0m" +actualtext);
	 				//System.out.println("\u001B[32mBooked Out By user by.\u001B[0m"+expectedval);
	 				List<WebElement> cellVal = driver.findElements(By.xpath("//*[@class='service-users-list__table']//*[ contains(@class,'mat-row cdk-row mears-table__data-row mears-table__data-row')]"));
					
	 			//	##################new way####################################################
	 				String cell1value= cellVal.get(i).getText();
	 				String input = cell1value;
	 				System.out.println(input);
	 		
	 				// Define regular expressions for matching the required information
	 		        String dateRegex = "\\d{1,2}/\\d{1,2}/\\d{4}";
	 		        String keyRegex = "Garage \\| \\d+";
	 		        String whoHasKeyRegex = "Owner";
	 		        String bookedOutByRegex = "   (\\w+ \\w+)"; // Capture "aasc HM"
	 		        String supplierRegex = "\\w+, \\w+";

	 		        // Compile regular expressions
	 		        Pattern datePattern = Pattern.compile(dateRegex);
	 		        Pattern keyPattern = Pattern.compile(keyRegex);
	 		       Pattern whoHasKeyPattern = Pattern.compile(whoHasKeyRegex);
	 		        Pattern bookedOutByPattern = Pattern.compile(bookedOutByRegex);
	 		        Pattern supplierPattern = Pattern.compile(supplierRegex);

	 		        // Use Matchers to find matches in the input string
	 		        Matcher dateMatcher = datePattern.matcher(input);
	 		        Matcher keyMatcher = keyPattern.matcher(input);
	 		        Matcher whoHasKeyMatcher = whoHasKeyPattern.matcher(input);
	 		        Matcher bookedOutByMatcher = bookedOutByPattern.matcher(input);
	 		        Matcher supplierMatcher = supplierPattern.matcher(input);

	 		        // Extract and print the information
	 		        if (dateMatcher.find()) {
	 		            System.out.println("Date: " + dateMatcher.group());
	 		        }
	 		        if (keyMatcher.find()) {
	 		            System.out.println("Key : " + keyMatcher.group());
	 		        }
	 		        if (whoHasKeyMatcher.find()) {
	 		            System.out.println("Who has Key : " + whoHasKeyMatcher.group());
	 		        }
	 		        if (bookedOutByMatcher.find()) {
	 		            System.out.println("Booked Out By : " + bookedOutByMatcher.group());
	 		        }
	 		        if (supplierMatcher.find()) {
	 		            System.out.println("Supplier : " + supplierMatcher.group());
	 		        }
	 		    
	 			  List<WebElement> checkboxes= driver.findElements(By.xpath("(//*[contains(@title,'"+Tab+"')]//*[contains(@class,'mat-checkbox-checked')])[last()]"));
	 		    	if(!checkboxes.isEmpty())
	 		    	{
	 		    		System.out.println("\u001B[32mCheckbox is checked.\u001B[0m");
	 		    		
	 		    	}
	 		    	else
	 		    	{
	 		    		System.out.println("\u001B[32mCheckbox is not checked.\u001B[0m");
	 		    	}
	 			}
	 			else
	 			{
	 				System.out.println("\u001B[32mExpected value :.\u001B[0m"+expectedval+ " does not match "+"\u001B[32mActual Value.\u001B[0m" +actualtext);
	 			}
	 		
	 		}
	 			}
	
public void ValidatetenancyStatus(String Tab,String elementID, String val) throws InterruptedException {
	 	
	 	expectedval=val;
	 	System.out.println("\u001B[32mExpected value: .\u001B[0m"+expectedval);
	 		List<WebElement> cells = driver.findElements(By.xpath("//*[@class='service-users-list__table']//*[ contains(@class,'mat-cell cdk-cell mears-table__cell cdk-column-tenancyStatus mat-column-tenancyStatus ng-star-inserted')]"));
	 		System.out.println("\u001B[32mNumber of Row present in Table : .\u001B[0m"+cells.size());
	 		for(int i=0;i<cells.size();i++)
	 		{
	 			Thread.sleep(7000);
	 			String actualtext=cells.get(i).getText();
	 			
	 			System.out.println(actualtext);
	 			//System.out.println("\u001B[32mActual value.\u001B[0m"+actualtext);
	 			if(cells.get(i).getText().equals(expectedval))
	 			{
	 				System.out.println("\u001B[32mExpected value :.\u001B[0m"+expectedval+ "=="+"\u001B[32mActual Value.\u001B[0m" +actualtext);
	 				//System.out.println("\u001B[32mBooked Out By user by.\u001B[0m"+expectedval);
	 				List<WebElement> cellVal = driver.findElements(By.xpath("//*[@class='service-users-list__table']//*[ contains(@class,'mat-row cdk-row mears-table__data-row mears-table__data-row')]"));
	 				String cell1value= cellVal.get(i).getText();
					String[] substring = cell1value.split(" ");
	 				String input = cell1value;
	 				System.out.println(input);
	 					
	 					    System.out.println("Tenancy Status: " + substring[0]);
	 					    System.out.println("Name: " + substring[1]);
	 					    System.out.println("Service: " + substring[2]);
	 					    System.out.println("SU Type: " + substring[3]);
	 				
	 			}
	 		}
	 		
	 		}
public void Communication_Detail(String Tab,String elementID, String val) throws InterruptedException {
 	
 	expectedval=val;
 	System.out.println("\u001B[32mExpected value: .\u001B[0m"+expectedval);
 		List<WebElement> cells = driver.findElements(By.xpath("//*[contains(@class,'communications-detail-list__wrapper ng-star-inserted')]//*[contains(@class,'mat-cell cdk-cell mears-table__cell communications-detail-list__table-cell cdk-column-information')]"));
 		System.out.println("\u001B[32mNumber of Row present in Table : .\u001B[0m"+cells.size());
 		for(int i=0;i<cells.size();i++)
 		{
 			Thread.sleep(7000);
 			String actualtext=cells.get(i).getText();
 			
 			System.out.println(actualtext);
 			//System.out.println("\u001B[32mActual value.\u001B[0m"+actualtext);
 			if(cells.get(i).getText().equals(expectedval))
 			{
 				System.out.println("\u001B[32mExpected value :.\u001B[0m"+expectedval+ "=="+"\u001B[32mActual Value.\u001B[0m" +actualtext);
 				//System.out.println("\u001B[32mBooked Out By user by.\u001B[0m"+expectedval);
 				List<WebElement> cellVal = driver.findElements(By.xpath("//*[contains(@class,'communications-detail-list__wrapper ng-star-inserted')]//*[ contains(@class,'mat-row cdk-row')]"));
 				String cell1value= cellVal.get(i).getText();
				String[] substring = cell1value.split(" ");
 				String input = cell1value;
 			//	System.out.println(input);
 					
 					    System.out.println("Type: " + substring[0]);
 					    System.out.println("Details: " + substring[1]);
 					   // System.out.println("Description" + substring[2]);
 					   List<WebElement> checkboxes= driver.findElements(By.xpath("(//*[contains(@class,'mat-checkbox-checked')])[last()]"));
        		    	if(!checkboxes.isEmpty())
        		    	{
        		    		System.out.println("\u001B[32mDefault Checkbox is checked.\u001B[0m");
        		    		
        		    	}
        		    	else
        		    	{
        		    		System.out.println("\u001B[32mDefault Checkbox is not checked.\u001B[0m");
        		    	}
        		    	
 				
 			}
 		}
 		
 		}

public void AddNewNotes(String Tab,String elementID, String val) throws InterruptedException {
 	
 	expectedval=val;
 	System.out.println("\u001B[32mExpected value: .\u001B[0m"+expectedval);
 		List<WebElement> cells = driver.findElements(By.xpath("//*[@class='"+elementID+"']//*[ contains(@class,'mat-cell cdk-cell mears-table__cell cdk-column-memNote mat-column-memNote')]"));
 		System.out.println("\u001B[32mNumber of Row present in Table : .\u001B[0m"+cells.size());
 		for(int i=0;i<cells.size();i++)
 		{
 			Thread.sleep(7000);
 			String actualtext=cells.get(i).getText();
 			
 			//System.out.println(actualtext);
 			//System.out.println("\u001B[32mActual value.\u001B[0m"+actualtext);
 			if(cells.get(i).getText().equals(expectedval))
 			{
 				System.out.println("\u001B[32mExpected value :.\u001B[0m"+expectedval+ "=="+"\u001B[32mActual Value.\u001B[0m" +actualtext);
 				//System.out.println("\u001B[32mBooked Out By user by.\u001B[0m"+expectedval);
 				List<WebElement> cellVal = driver.findElements(By.xpath("//*[@class='"+elementID+"']//*[ contains(@class,'mat-row cdk-row mears-table__data-row--hover')]"));
 				String cell1value= cellVal.get(i).getText();
				String[] substring = cell1value.split(" ");
 				String input = cell1value;
 			//	System.out.println(input);
 					
 					    System.out.println("Date: " + substring[0] +substring[1]);
 					    System.out.println("By: " + substring[2]);
 					    System.out.println("Type: " + substring[3]);
 					    System.out.println("Sub Type: " + substring[4]);
 					   //System.out.println("Notes " + substring[5]);
 				
 			}
 		}
 		
 		}

public void ClosedTask(String Tab,String elementID, String val) throws InterruptedException {
 	
 	expectedval=val;
 	System.out.println("\u001B[32mExpected value: .\u001B[0m"+expectedval);
 		List<WebElement> cells = driver.findElements(By.xpath("//*[@class='tasks-panel__wrapper']//*[ contains(@class,'mat-cell cdk-cell mears-table__cell mears-table__cell-date-time cdk-column-status mat-column-status ng')]"));
 		System.out.println("\u001B[32mNumber of Row present in Table : .\u001B[0m"+cells.size());
 		for(int j=0;j<cells.size();j++)
 		{
 			Thread.sleep(7000);
 			String actualtext=cells.get(j).getText();
 			
 			System.out.println(actualtext);
 			//System.out.println("\u001B[32mActual value.\u001B[0m"+actualtext);
 			if(cells.get(j).getText().equals(expectedval))
 			{
 				System.out.println("\u001B[32mExpected value :.\u001B[0m"+expectedval+ "=="+"\u001B[32mActual Value.\u001B[0m" +actualtext);
 				//System.out.println("\u001B[32mBooked Out By user by.\u001B[0m"+expectedval);
 				List<WebElement> cellVal = driver.findElements(By.xpath("//*[@class='tasks-panel__wrapper']//*[ contains(@class,'mat-row cdk-row')]"));
 				String cell1value= cellVal.get(j).getText();
 				String[] words = cell1value.split(" ");
                
 		        // Initialize variables to hold the extracted values
 		        String title = "";
 		        String description = "";
 		        String status = "";
 		        String date = "";

 		        for (int i = 0; i < words.length; i++) {
 		            if (i == 0) {
 		                title = "Title: " + words[i];
 		            } else if (words[i].equals("Please")) {
 		                description = "Description: " + "Please provide approval decision for this property";
 		            } else if (words[i].equals("Closed")) {
 		                status = "Status: " + "Closed";
 		            } else if (words[i].matches("\\d{2}/\\d{2}/\\d{4}")) {
 		                date = "Date: " + words[i];
 		            }
 		        }

 		        // Print the formatted output
 		        System.out.println(title);
 		        System.out.println(description);
 		        System.out.println(status);
 		        System.out.println(date);
 		    }
 				
 			}
 		}
 		
public void FilterByUser(String Tab,String elementID, String val) throws InterruptedException {
 	
 	expectedval=val;
 	System.out.println("\u001B[32mExpected value: .\u001B[0m"+expectedval);
 		List<WebElement> cells = driver.findElements(By.xpath("(//*[contains(@id,'add-service-user_save-button')])[1]"));
 		System.out.println("\u001B[32mNumber of Row present in Table : .\u001B[0m"+cells.size());
 		for(int j=0;j<cells.size();j++)
 		{
 			Thread.sleep(7000);
 			String actualtext=cells.get(j).getText();
 			
 			System.out.println(actualtext);
 			//System.out.println("\u001B[32mActual value.\u001B[0m"+actualtext);
 			if(cells.get(j).getText().equals(expectedval))
 			{
 				System.out.println("\u001B[32mExpected value :.\u001B[0m"+expectedval+ "=="+"\u001B[32mActual Value.\u001B[0m" +actualtext);
 				//System.out.println("\u001B[32mBooked Out By user by.\u001B[0m"+expectedval);
 				List<WebElement> cellVal = driver.findElements(By.xpath("//*[contains(@class,'list__wrapper')]//*[ contains(@class,'mat-row cdk-row')]"));
 				String cell1value= cellVal.get(j).getText();
				String[] substring = cell1value.split(" ");
 				String input = cell1value;
 				 String[] words = input.split(" ");
 				 System.out.println(input);
 				// Initialize variables to hold the extracted values
 		        String title = "Title: Request";
 		        String description = "Description: ";
 		        String status = "Status: ";
 		        String createdOn = "CreatedOn: ";
 		        String dueBy = "Due By: ";
 		        String completeRequest = "";

 		        boolean completeRequestFlag = false;

 		        for (int i = 1; i < words.length - 1; i++) {
 		            if (words[i].equals("Open") || words[i].equals("Complete")) {
 		                // Extract the status part
 		                status = "Status: " + words[i];
 		            } else if (words[i].matches("\\d{2}/\\d{2}/\\d{4}")) {
 		                // Extract date parts
 		                createdOn = "CreatedOn: " + words[i];
 		                dueBy = "Due By: " + words[i];
 		                completeRequest = "Complete Request";
 		                completeRequestFlag = true;
 		            } else {
 		                // Extract the description part
 		                description += words[i] + " ";
 		            }
 		        }

 		        // Print the formatted output
 		        System.out.println(title);
 		        System.out.println(description.trim());
 		        System.out.println(status);
 		        System.out.println(createdOn);
 		        System.out.println(dueBy);
 		        if (completeRequestFlag) {
 		            System.out.println(completeRequest);
 		        }
 		    }
 		}
 			}
public void ValidateClientStatus(String Tab,String elementID, String val) throws InterruptedException {
 	
 	expectedval=val;
 	System.out.println("\u001B[32mExpected value: .\u001B[0m"+expectedval);
 		List<WebElement> cells = driver.findElements(By.xpath("//*[@matsortactive='reported']//*[contains(@class,'mat-cell cdk-cell mears-table__cell cdk-column-status mat-column-status ng-star-inserted')]"));
 		System.out.println("\u001B[32mNumber of Row present in Table : .\u001B[0m"+cells.size());
 		for(int i=0;i<cells.size();i++)
 		{
 			Thread.sleep(7000);
 			String actualtext=cells.get(i).getText();
 			
 			System.out.println(actualtext);
 			//System.out.println("\u001B[32mActual value.\u001B[0m"+actualtext);
 			if(cells.get(i).getText().equals(expectedval))
 			{
 				System.out.println("\u001B[32mExpected value :.\u001B[0m"+expectedval+ "=="+"\u001B[32mActual Value.\u001B[0m" +actualtext);
 				//System.out.println("\u001B[32mBooked Out By user by.\u001B[0m"+expectedval);
 				List<WebElement> cellVal = driver.findElements(By.xpath("//*[@matsortactive='reported']//*[ contains(@class,'mat-row cdk-row mears-table__data-row, mears-table__data-row--hover ng-star-inserted')]"));
 				String cell1value= cellVal.get(i).getText();
				String[] substring = cell1value.split(" ");
 				String input = cell1value;
 				System.out.println(input);
 					
 					    System.out.println("JobNo1: " + substring[0]);
 					    System.out.println("Description: " + substring[1]+substring[2]);
 					    System.out.println("Status: " + substring[3]);
 					   
 				
 			}
 		}
 		
 		}
public void ValidateJobNumber(String Tab,String elementID, String val) throws InterruptedException {
 	
 	expectedval=val;
 	System.out.println("\u001B[32mExpected value: .\u001B[0m"+expectedval);
 		List<WebElement> cells = driver.findElements(By.xpath("//*[@class='mat-row cdk-row mears-table__data-row, mears-table__data-row--hover ng-star-inserted']//*[ contains(@class,'mat-cell cdk-cell mears-table__cell cdk-column-jobNo1 mat-column-jobNo1 ng-star-inserted')]"));
 		System.out.println("\u001B[32mNumber of Row present in Table : .\u001B[0m"+cells.size());
 		for(int i=0;i<cells.size();i++)
 		{
 			Thread.sleep(7000);
 			String actualtext=cells.get(i).getText();
 			
 			System.out.println(actualtext);
 			//System.out.println("\u001B[32mActual value.\u001B[0m"+actualtext);
 			if(cells.get(i).getText().equals(expectedval))
 			{
 				System.out.println("\u001B[32mExpected value :.\u001B[0m"+expectedval+ "=="+"\u001B[32mActual Value.\u001B[0m" +actualtext);
 				//System.out.println("\u001B[32mBooked Out By user by.\u001B[0m"+expectedval);
 				List<WebElement> cellVal = driver.findElements(By.xpath("//*[@class='mat-row cdk-row mears-table__data-row, mears-table__data-row--hover ng-star-inserted']"));
 				String cell1value= cellVal.get(i).getText();
				String[] substring = cell1value.split(" ");
 				String input = cell1value;
 				System.out.println(input);
 					
 					    System.out.println("Contract: " + substring[0]+substring[1]+substring[2]+substring[3]);
 					    System.out.println("Job No: " + substring[4]);
 			}
 		}
 		
 		}
public void ValidateChangeForAuditLog(String Tab,String elementID, String val) throws InterruptedException {
 	
 	expectedval=val;
 	System.out.println("\u001B[32mExpected value: .\u001B[0m"+expectedval);
 		List<WebElement> cells = driver.findElements(By.xpath("//*[@class='mat-cell cdk-cell mears-table__cell cdk-column-description mat-column-description ng-star-inserted']//*[text()='"+Tab+"']"));
 		System.out.println("\u001B[32mNumber of Row present in Table : .\u001B[0m"+cells.size());
 		for(int i=0;i<cells.size();i++)
 		{
 			Thread.sleep(7000);
 			String actualtext=cells.get(i).getText();
 			
 			System.out.println(actualtext);
 			//System.out.println("\u001B[32mActual value.\u001B[0m"+actualtext);
 			if(cells.get(i).getText().equals(expectedval))
 			{
 				System.out.println("\u001B[32mExpected value :.\u001B[0m"+expectedval+ "=="+"\u001B[32mActual Value.\u001B[0m" +actualtext);
 				List<WebElement> cellVal = driver.findElements(By.xpath("//*[@class='mat-cell cdk-cell mears-table__cell cdk-column-description mat-column-description ng-star-inserted']"));
 				String cell1value= cellVal.get(i).getAttribute("innerText");
 				  System.out.println("\u001B[32mQuantity: .\u001B[0m "+cell1value);
 			}  	}}
public void ValidateStatus(String Tab,String elementID, String val) throws InterruptedException {
 	
 	expectedval=val;
 	System.out.println("\u001B[32mExpected value: .\u001B[0m"+expectedval);
 		List<WebElement> cells = driver.findElements(By.xpath("//*[contains(@class,'"+Tab+"')]//*[text()='"+val+"']"));
 		System.out.println("\u001B[32mNumber of Row present in Table : .\u001B[0m"+cells.size());
 		for(int i=0;i<cells.size();i++)
 		{
 			Thread.sleep(7000);
 			String actualtext=cells.get(i).getText();
 			
 			System.out.println(actualtext);
 			//System.out.println("\u001B[32mActual value.\u001B[0m"+actualtext);
 			if(cells.get(i).getText().equals(expectedval))
 			{
 				System.out.println("\u001B[32mExpected value :.\u001B[0m"+expectedval+ "=="+"\u001B[32mActual Value.\u001B[0m" +actualtext);
 				List<WebElement> cellVal = driver.findElements(By.xpath("//*[@class='mat-cell cdk-cell mears-table__cell cdk-column-description mat-column-description ng-star-inserted']"));
 				String cell1value= cellVal.get(i).getAttribute("innerText");
 				  System.out.println("\u001B[32mQuantity: .\u001B[0m "+cell1value);
 			}  	}}
public void ValidateOriginalVal(String Tab,String elementID, String val) throws InterruptedException {
 	
 	expectedval=val;
 	System.out.println("\u001B[32mExpected value: .\u001B[0m"+expectedval);
 		List<WebElement> cells = driver.findElements(By.xpath("//*[@class='mat-cell cdk-cell mears-table__cell cdk-column-type mat-column-type ng-star-inserted']"));
 		System.out.println("\u001B[32mNumber of Row present in Table : .\u001B[0m"+cells.size());
 		for(int i=0;i<cells.size();i++)
 		{
 			Thread.sleep(7000);
 			String actualtext=cells.get(i).getText();
 			
 			System.out.println(actualtext);
 			//System.out.println("\u001B[32mActual value.\u001B[0m"+actualtext);
 			if(cells.get(i).getText().equals(expectedval))
 			{
 				System.out.println("\u001B[32mExpected value :.\u001B[0m"+expectedval+ "=="+"\u001B[32mActual Value.\u001B[0m" +actualtext);
 				List<WebElement> cellVal = driver.findElements(By.xpath("//*[@class='mat-cell cdk-cell mears-table__cell cdk-column-description mat-column-description ng-star-inserted']"));
 				String cell1value= cellVal.get(i).getAttribute("innerText");
 				  System.out.println("\u001B[32mQuantity: .\u001B[0m "+cell1value);
 			}  	}}

	public void selectGroup(String option) throws InterruptedException {
	 			
		Wait.untilPageLoadComplete(driver);
		WebElement groupoption = driver.findElement(By.xpath("//*[@role='group']//*[contains(text(),'"+option+"')]"));
		 try {
				
				groupoption.click();
		 	}
		 catch(Exception e)
		 {
				util.actionMethodClick(driver, groupoption);
			}
 		
}
	public void ClickFilterDashboard() throws InterruptedException {
			
		Wait.untilPageLoadComplete(driver);
		 try {
				
			 Filteratask.click();
		 	}
		 catch(Exception e)
		 {
				util.actionMethodClick(driver, Filteratask);
			}
 		
}
	
	public void Clickshowallchkbox() throws InterruptedException {
		
		 WebElement checkbox= driver.findElement(By.xpath("(//*[@class='mat-checkbox mat-accent']//*[contains(@class,'mat-checkbox-frame')])[1]"));
	   		 Wait.elementToBeClickable(driver, checkbox, 3);
	   		 util.actionMethodClick(driver, checkbox);
 		
}   
	public void ClickAddAdress(String add,String option) throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@data-placeholder='enter any part of an address']")).sendKeys(add,Keys.ENTER);
		 WebElement Addaddress= driver.findElement(By.xpath("//*[@class='mat-option-text']//span[contains(text(),'"+option+"')]"));
	   		 Wait.elementToBeClickable(driver, Addaddress, 3);
	   		 util.actionMethodClick(driver, Addaddress);
		
}   
	public void CalendarDateValidation() throws InterruptedException {
		 WebElement calendar = driver.findElement(By.xpath("//*[contains(@formcontrolname,'dueDate')]"));
	        calendar.click();
	        driver.findElement(By.xpath("//*[@aria-label='Choose month and year']")).click();
	    	// Get the current date
			Date currentDate= new Date();
			Calendar calender= Calendar.getInstance();
			calender.setTime(currentDate);
			
			int yearToSelect = calender.get(Calendar.YEAR);
			int monthToSelect =  calender.get(Calendar.MONTH);
			//for month
			LocalDate currentD= LocalDate.now();
			int currentMon= currentD.getMonthOfYear();
			Month month = Month.of(currentMon);
			String fullMonth = month.getDisplayName(TextStyle.FULL, Locale.ENGLISH);
			int dayToSelect =  calender.get(Calendar.DAY_OF_MONTH);
			System.out.println("Today's Year "+yearToSelect);
			System.out.println("Today's Month "+fullMonth);
			System.out.println("Today's Date  "+dayToSelect);
			//Find the year, month and date cells and click them
			 System.out.println("Select the Today Year");
			WebElement fromyear= driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+yearToSelect+"']"));
			Wait.elementToBeClickable(driver, fromyear, 3);
			testutil.actionMethodClick(driver, fromyear);
				Thread.sleep(2000);
				//System.out.println("Select the Today month");
				 String monthsubstring = fullMonth.substring(0,3);
				// System.out.println("Sub string  "+monthsubstring);
						//WebElement monthselected = driver.findElement(By.xpath("(//*[contains(text(),'"+monthsubstring+"')])[2]"));
				 WebElement frommonth= driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+fullMonth+" "+yearToSelect+"']"));
					Wait.elementToBeClickable(driver, frommonth, 3);
					testutil.actionMethodClick(driver, frommonth);
							
		//System.out.println("Select the Today date");
		 Wait.untilPageLoadComplete(driver,2000);	
		 WebElement CurrentDate=driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+dayToSelect+" " +fullMonth+" "+ yearToSelect+"']"));
			Wait.elementToBeClickable(driver, CurrentDate, 3);
			testutil.actionMethodClick(driver, CurrentDate);
			System.out.println("Select the Today date "+CurrentDate.getText());
			CurrentDate.click();
			
}
	 public void clickOnContractSelectionchk(String Itemcount) throws InterruptedException
	    {
	    	int item = Integer.parseInt(Itemcount);
	   	 System.out.println("Number of item to be selected is "+item);
	   	 for(int i=0;i<item;i++)
	   	 {
	   		 int a=i+1;
	   		 WebElement checkbox= driver.findElement(By.xpath("(//*[@class='table-container']//*[contains(@class,'mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin')])["+a+"]"));
	   		// System.out.println(a);
	   		// Wait.elementToBeClickable(driver, checkbox, 3);
	   		 Thread.sleep(1000);
	   	    // util.actionMethodClick(driver, checkbox);
	   		checkbox.click();
	   	 }
	    	
	    }
	 public void clickOnNext(String option,String val) throws InterruptedException
	    {
	    	try {
	    		Thread.sleep(2000);
	    		// WebElement nextbtn= driver.findElement(By.xpath("//*[@class='"+option+"']//span[normalize-space()='"+val+"']"));
	    		 Boolean flag = false;
	 			while (!flag) {
	 				List<WebElement> nextbtn = driver.findElements(By.xpath("//*[@class='"+option+"']//span[normalize-space()='"+val+"']"));
	 				for (int i = 0; i < nextbtn.size(); i++) {
	 					if (isClickable(nextbtn.get(i))) {
	 						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",nextbtn.get(i) );
	 						util.actionMethodClick(driver, nextbtn.get(i));
	 						flag = true;
	 						i = nextbtn.size();
	 						
	 			System.out.println("User select option: " +option );
	 			
	 		}
	    	}
	 			}
	    	}catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
	    }
	 public void clickOnchk(String Itemcount, String value) throws InterruptedException
	    {
	    	int item = Integer.parseInt(Itemcount);
	   	 System.out.println("Number of item to be selected is "+item);
	   	 for(int i=0;i<item;i++)
	   	 {
	   		 int a=i+1;
	   		 WebElement checkbox= driver.findElement(By.xpath("(//*[starts-with(@formcontrolname,'"+value+"')]//*[starts-with(@class,'mat-checkbox-inner-container')])["+a+"]"));
	   		// System.out.println(a);
	   		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",checkbox );
	   		 Wait.elementToBeClickable(driver, checkbox, 3);
	   		// util.actionMethodClick(driver, checkbox);
	   		try {
	   		 util.actionMethodClick(driver, checkbox);
	   		//checkbox.click();
	   	    	}
	   	    	catch(Exception e)
	   	    	{
	   	    		util.actionMethodClick(driver, checkbox);
	   	}
	   	 }
	    	
	    }
	 public void selectOwnerSurname(String user) throws InterruptedException
	    {
	    	try {
	    		Wait.untilPageLoadComplete(driver);
	    		System.out.println(user);
	    		WebElement ContinuebtnDisable = driver.findElement(By.xpath("(//*[contains(text(),'"+user +"')])[last()]"));
	    		util.actionMethodClick(driver, ContinuebtnDisable);
	    	}
	    	catch (Exception e)
	    	{
	    		
	    	}
}
	 public void clickchkTask() throws InterruptedException
	    {
		 Wait.untilPageLoadComplete(driver);
		 WebElement Checkboxtask= driver.findElement(By.xpath("//*[@class='tasks-panel__wrapper']//*[starts-with(@class,'mat-checkbox-inner-container')]"));
	    	try {
	    		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",Checkboxtask);
	    		util.actionMethodClick(driver, Checkboxtask);
	    	}
	    	catch (Exception e)
	    	{
	    	    e.printStackTrace();	
	    	    util.actionMethodClick(driver, Checkboxtask);
	    	}
	    }
	    	 public void clickActiveServiceUser(String Value) throws InterruptedException
	 	    {
	 	    
	 	    		Wait.untilPageLoadComplete(driver);
	 	    		WebElement Activebtn= driver.findElement(By.xpath("(//*[@matsortactive='staffName']//*[contains(@class,'mat-row cdk-row mears-table__data-row mears-table__data-row--hover ng-star-inserted')]//*[contains(text(),'Active')])[1]"));
	 	    		//((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",Activebtn);
	 	    		try {
	 	    			util.actionMethodClick(driver, Activebtn);
	 	  	   	    	}
	 	  	   	    	catch(Exception e)
	 	  	   	    	{
	 	  	   	    	Activebtn.click();
	 	  	   	    	}
	 	    		}
	    	 public void ServiceUsertxt(String Value) throws InterruptedException
		 	    {
		 	    
		 	    		Wait.untilPageLoadComplete(driver);
		 	    		
		 	    		WebElement Serviceusertxt= driver.findElement(By.xpath("//*[@class='task-filter-form__wrapper']//*[contains(text(),'search')]"));
		 	    		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",Serviceusertxt);
		 	    		try {
		 	    			util.actionMethodClick(driver, Serviceusertxt);
		 	  	   	    	}
		 	  	   	    	catch(Exception e)
		 	  	   	    	{
		 	  	   	    	Serviceusertxt.click();
		 	  	   	    	}
		 	    		}
	    	 public void UpdateWeekLater(String week) throws InterruptedException
	    	    {
	    		 switch(week)
	    			{
	    		 /*
	    			case "":
	    	    		Wait.untilPageLoadComplete(driver);
	    	    		gettingDate.click();
	    	    		 String userInput = "2023-12-28";
	    	    		 LocalDate userDate = LocalDate.parse(userInput);
	    	    		 LocalDate oneWeekLater = userDate.plusWeeks(1);
	    	    		 //for year for next week
	    	     		int lateryear =oneWeekLater.getYear();
	    	     		System.out.println("Later Year "+lateryear);
	    	     		
	    	     		//for month for next week
	    	     		int laterMon= oneWeekLater.getMonthOfYear();
	    	     		Month month = Month.of(laterMon);
	    	     		String fullMonth = month.getDisplayName(TextStyle.FULL, Locale.ENGLISH);
	    	     		System.out.println("Later Month "+fullMonth);
	    	 			
	    	            // for date 1 week later
	    	     		int Laterdate=oneWeekLater.getDayOfMonth();
	    	     		System.out.println("Later Year "+Laterdate);
	    	             
	    	     		// output
	    	 			System.out.println("The current date is "+userDate);
	    	 			System.out.println("The date week later is "+oneWeekLater);
	    	 			
	    	 			// Year and month to select 1 week later
	    	 			
	    	 			driver.findElement(By.xpath("//*[@aria-label='Choose month and year']")).click();
	    	 			WebElement fromyear= driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+lateryear+"']"));
	    	 			Wait.elementToBeClickable(driver, fromyear, 3);
	    	 			testutil.actionMethodClick(driver, fromyear);
	    	 			System.out.println("Select the month");
	    	 			WebElement frommonth= driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+fullMonth+" "+lateryear+"']"));
	    	 			Wait.elementToBeClickable(driver, frommonth, 3);
	    	 			testutil.actionMethodClick(driver, frommonth);
	    	 			WebElement fromDate= driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+Laterdate+" " +fullMonth+" "+ lateryear+"']"));
	    	 			System.out.println("Select the date");
	    	 			System.out.println("click on date "+fromDate.getText());
	    	 			Wait.elementToBeClickable(driver, fromDate, 3);
	    	 			testutil.actionMethodClick(driver, fromDate);
	    			*/
	    			case "one":
	    				WebDriverWait wait = new WebDriverWait(driver, Duration.ofMillis(10));
	    				List<WebElement> crossButtons = driver.findElements(By.xpath("//button[@aria-label='Open calendar']//*[text()='clear']"));

	    				if (!crossButtons.isEmpty()) {
	    				    WebElement crossButton = crossButtons.get(0);
	    				    testutil.actionMethodClick(driver, crossButton);
	    				    // Proceed with interactions
	    				} else {
	    				    System.out.println("Cross button not present. Moving to the next step...");
	    				    // Handle accordingly
	    				}

	    	    		Wait.untilPageLoadComplete(driver);
	    	    		gettingDate.click();
	    	    		 LocalDate currentDate = LocalDate.now();
	    	    		 LocalDate oneWeekLater = currentDate.plusWeeks(1);
	    	    		 //for year for next week
	    	     		int lateryear =oneWeekLater.getYear();
	    	     		System.out.println("Later Year "+lateryear);
	    	     		
	    	     		//for month for next week
	    	     		int laterMon= oneWeekLater.getMonthOfYear();
	    	     		Month month = Month.of(laterMon);
	    	     		String fullMonth = month.getDisplayName(TextStyle.FULL, Locale.ENGLISH);
	    	     		System.out.println("Later Month "+fullMonth);
	    	 			
	    	            // for date 1 week later
	    	     		int Laterdate=oneWeekLater.getDayOfMonth();
	    	     		System.out.println("Later Year "+Laterdate);
	    	             
	    	     		// output
	    	 			System.out.println("The current date is "+currentDate);
	    	 			System.out.println("The date week later is "+oneWeekLater);
	    	 			
	    	 			// Year and month to select 1 week later
	    	 			
	    	 			driver.findElement(By.xpath("//*[@aria-label='Choose month and year']")).click();
	    	 			WebElement fromyear= driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+lateryear+"']"));
	    	 			Wait.elementToBeClickable(driver, fromyear, 3);
	    	 			testutil.actionMethodClick(driver, fromyear);
	    	 			System.out.println("Select the month");
	    	 			WebElement frommonth= driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+fullMonth+" "+lateryear+"']"));
	    	 			Wait.elementToBeClickable(driver, frommonth, 3);
	    	 			testutil.actionMethodClick(driver, frommonth);
	    	 			WebElement fromDate= driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+Laterdate+" " +fullMonth+" "+ lateryear+"']"));
	    	 			System.out.println("Select the date");
	    	 			System.out.println("click on date "+fromDate.getText());
	    	 			Wait.elementToBeClickable(driver, fromDate, 3);
	    	 			testutil.actionMethodClick(driver, fromDate);
	    	 			break;
	    			case "two":
	    				Wait.untilPageLoadComplete(driver);
	    				WebElement clear_calender= driver.findElement(By.xpath("//button[@aria-label='Open calendar']//*[text()='clear']"));
	    				testutil.actionMethodClick(driver, clear_calender);
	    	    		gettingDate.click();
	    	    		 LocalDate currentDate2 = LocalDate.now();
	    	    		 LocalDate oneWeekLater2 = currentDate2.plusWeeks(2);
	    	    		
	    	    		 //for year for next week
	    	    		int lateryear2 =oneWeekLater2.getYear();
	    	    		System.out.println("Later Year "+lateryear2);
	    	    		
	    	    		//for month for next week
	    	    		int laterMon2= oneWeekLater2.getMonthOfYear();
	    	    		Month month2 = Month.of(laterMon2);
	    	    		String fullMonth2 = month2.getDisplayName(TextStyle.FULL, Locale.ENGLISH);
	    	    		System.out.println("Later Month "+fullMonth2);
	    				
	    	           // for date 1 week later
	    	    		int Laterdate2=oneWeekLater2.getDayOfMonth();
	    	    		System.out.println("Later Year "+Laterdate2);
	    	            
	    	    		// output
	    				System.out.println("The current date is "+currentDate2);
	    				System.out.println("The date week later is "+oneWeekLater2);
	    				
	    				// Year and month to select 1 week later
	    				
	    				driver.findElement(By.xpath("//*[@aria-label='Choose month and year']")).click();
	    				WebElement fromyear2= driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+lateryear2+"']"));
	    				Wait.elementToBeClickable(driver, fromyear2, 3);
	    				testutil.actionMethodClick(driver, fromyear2);
	    				System.out.println("Select the month");
	    				WebElement frommonth2= driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+fullMonth2+" "+lateryear2+"']"));
	    				Wait.elementToBeClickable(driver, frommonth2, 3);
	    				testutil.actionMethodClick(driver, frommonth2);
	    				WebElement fromDate2= driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+Laterdate2+" " +fullMonth2+" "+ lateryear2+"']"));
	    				System.out.println("Select the date");
	    				System.out.println("click on date "+fromDate2.getText());
	    				Wait.elementToBeClickable(driver, fromDate2, 3);
	    				testutil.actionMethodClick(driver, fromDate2);
	    				break;
	    	    		} 
	    	    }
	    	 
	    	 public void updateCalendertwoweekLater() throws InterruptedException {
	    		 Wait.untilPageLoadComplete(driver);
	    		 Thread.sleep(1000);
	    		 WebElement txtcalender= driver.findElement(By.xpath("//*[@formcontrolname='dateRequired']"));
	    		 try {
 				testutil.actionMethodClick(driver, txtcalender);
	    		 }
	    		 catch(Exception e)
	  	   	    	{
	    			 txtcalender.click();
	  	   	    	}
 				//txtcalender.click();
 	    		 LocalDate currentDate2 = LocalDate.now();
 	    		 LocalDate oneWeekLater2 = currentDate2.plusWeeks(2);
 	    		
 	    		 //for year for next week
 	    		int lateryear2 =oneWeekLater2.getYear();
 	    		System.out.println("Later Year "+lateryear2);
 	    		
 	    		//for month for next week
 	    		int laterMon2= oneWeekLater2.getMonthOfYear();
 	    		Month month2 = Month.of(laterMon2);
 	    		String fullMonth2 = month2.getDisplayName(TextStyle.FULL, Locale.ENGLISH);
 	    		System.out.println("Later Month "+fullMonth2);
 				
 	           // for date 1 week later
 	    		int Laterdate2=oneWeekLater2.getDayOfMonth();
 	    		System.out.println("Later Date "+Laterdate2);
 	            
 	    		// output
 				System.out.println("The current date is "+currentDate2);
 				System.out.println("The date Two week later is "+oneWeekLater2);
 				
 				// Year and month to select 2 week later
 				System.out.println("Select the Year");
 				driver.findElement(By.xpath("//*[@aria-label='Choose month and year']")).click();
 				WebElement fromyear2= driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+lateryear2+"']"));
 				Wait.elementToBeClickable(driver, fromyear2, 3);
 				testutil.actionMethodClick(driver, fromyear2);
 				System.out.println("Select the month"+fullMonth2+lateryear2);
 				WebElement frommonth2= driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+fullMonth2+" "+lateryear2+"']"));
 				Wait.elementToBeClickable(driver, frommonth2, 3);
 				testutil.actionMethodClick(driver, frommonth2);
 				WebElement fromDate2= driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+Laterdate2+" " +fullMonth2+" "+ lateryear2+"']"));
 				System.out.println("Select the date");
 				System.out.println("click on date "+fromDate2.getText());
 				Wait.elementToBeClickable(driver, fromDate2, 3);
 				testutil.actionMethodClick(driver, fromDate2); 
	    	 }
	    	 public void ClickCalenderUnderTab(String  val,String setMonth, String setYear,String setDate) throws InterruptedException
	    	    {
	    			WebElement dropdownserviceuser = driver.findElement(By.xpath("//*[contains(@formcontrolname,'"+val+"')]"));
	    			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",dropdownserviceuser );
	    			Wait.elementToBeClickable(driver, dropdownserviceuser, 2);
	    			testutil.actionMethodClick(driver, dropdownserviceuser);
	    			Wait.untilPageLoadComplete(driver);
	    			
	    			driver.findElement(By.xpath("//*[@aria-label='Choose month and year']")).click();
	    			WebElement fromyear= driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+setYear+"']"));
	    			Wait.elementToBeClickable(driver, fromyear, 3);
	    			testutil.actionMethodClick(driver, fromyear);
	    			//System.out.println("Select the year" +fromyear);
	    			//System.out.println("Select the month");
	    			WebElement frommonth= driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+setMonth+" "+setYear+"']"));
	    			Wait.elementToBeClickable(driver, frommonth, 3);
	    			//System.out.println("Select the month" +frommonth);
	    			testutil.actionMethodClick(driver, frommonth);
	    			WebElement fromDate= driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+setDate+" " +setMonth+" "+ setYear+"']"));
	    			System.out.println("Select the date");
	    			System.out.println("click on date "+fromDate.getText());
	    			    int SelectedDate = Integer.parseInt(setDate);
	    				Date currentdate = new Date();
	    				SimpleDateFormat formatter= new SimpleDateFormat("d");
	    				int currentday= Integer.parseInt(formatter.format(currentdate));
	    				String datetoBook = formatter.format(currentdate);
	    				System.out.println("The current date is "+currentday);
	    				
	    				if (SelectedDate > currentday)
	    				{
	    					boolean isdatedisabled=fromDate.getAttribute("class").contains("disabled");
	    					if(isdatedisabled) {
	    						System.out.println("The selected date ' "+SelectedDate+"' is disabled and not clickable. ");	
	    						WebElement CurrentDate=driver.findElement(By.xpath("//*[starts-with(@class,'mat-calendar-body-cell-container ng-star-inserted')]//*[@aria-label='"+currentday+" " +setMonth+" "+ setYear+"']"));
	    						System.out.println("The selecting the current date");
	    					//	CurrentDate.click();
	    						testutil.actionMethodClick(driver, CurrentDate);
	    					}
	    					else {
	    						
	    						System.out.println("The selected date ' "+SelectedDate+"' is not enable and clickable. ");	
	    						fromDate.click();
	    					}
	    						
	    					}
	    					else {
	    						System.out.println("The selected date fromDate' "+SelectedDate+"' is enable and clickable. ");	
	    						fromDate.click();
	    						//testutil.actionMethodClick(driver, fromDate);
	    					}
	    				
	    	    }
	    	    
	 	 public void IsButtonEnabled()	
	 	 {
	 		WebElement IsbuttonEnable = driver.findElement(By.xpath("//*[contains(@class,'mat-save mat-button-disabled') or contains(@class,'mat-button-base mat-save')]"));
			 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",IsbuttonEnable );
			 boolean disabledAttribute = IsbuttonEnable.getAttribute("class").contains("mat-button-disabled");
			 System.out.println(disabledAttribute);
			 
			 if (IsbuttonEnable.getAttribute("class").contains("mat-button-disabled")) {
		            
		            System.out.println("\u001B[31mSave button is disabled. Validation failed! .\u001B[0m");
		        } else {
		           
		            System.out.println("\u001B[32m Save button is enabled. Validation passed! .\u001B[0m");
		           
		        }

	 	 }
	 	 public boolean isElementPresent(By by)
	 	 {
	 		 List<WebElement> ele = driver.findElements(by);
	 		 if(ele.isEmpty())
	 			 return false;
	 		 else
	 			 return true;
	 	 }
	 	 public void verifysearchresult(String searchtext)
	 	 {
	 		 By ele;
	 		// WebElement ele;
	 		 ele= By.xpath("//*[@class='ng-star-inserted']//*[contains(text(),'"+searchtext+"')]");
	 		 //String fieldValue = ele.getAttribute("value");
	 		// System.out.println(fieldValue);
	 		 boolean present= isElementPresent(ele);
	 		 if(present)
	 		 {
	 			 System.out.println("Search result contains " +searchtext );
	 		 }
	 		 else
	 		 {
	 			System.out.println("Search result not contains" +searchtext );
	 		 }
	 	 }
	 	 public void localsearch(DataTable datatable)
	 	 {
	 		 int i,j;
	 		 List<List<String>> data = datatable.cells();
	 		 for(i=0;i<1;i++) {
	 			 for(j=0;j<3;j++) {
	 				 Wait.untilPageLoadComplete(driver);
	 				 verifysearchresult(data.get(i).get(j));
	 			 }
	 		 }
	 	 }
	 	 public void clickchkTask(String address) throws InterruptedException
		    {
	 		Wait.untilPageLoadComplete(driver);
	 		WebElement Checkboxtask= driver.findElement(By.xpath("//*[starts-with(@class,'mat-checkbox-background')]//*[contains(@class,'mat-checkbox-mixedmark')]"));
		    	try {
		    		
		    		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",Checkboxtask);
		    		testutil.jsclick(driver, Checkboxtask);
		    	}
		    	catch (Exception e)
		    	{
		    		util.actionMethodClick(driver, Checkboxtask);
		    	    e.printStackTrace();	
		    	}
		    }
	 	 public void clickOnChk(String address) throws InterruptedException
		    {
	 		Wait.untilPageLoadComplete(driver);
	 		WebElement Checkboxtask= driver.findElement(By.xpath("//*[starts-with(@class,'"+address+"')]//*[contains(@class,'mat-checkbox-mixedmark')]"));
		    	try {
		    		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",Checkboxtask);
		    		testutil.jsclick(driver, Checkboxtask);
		    	}
		    	catch (Exception e)
		    	{
		    		util.actionMethodClick(driver, Checkboxtask);
		    	    e.printStackTrace();	
		    	}
		    }
	 	 public void FieldNotVisible(String val) throws InterruptedException
		    {
	 		List<WebElement> options  = driver.findElements(By.xpath("//*[contains(text(),'" + val + "')]"));
	 		boolean editServiceUserOptionPresent = false;
	 	// Check if "Edit Service User" option is present
	        for (WebElement option : options) {
	            if (option.getText().equals(val)) {
	                editServiceUserOptionPresent = true;
	                break;
	            }
	        }
	     // Output the result
	        if (editServiceUserOptionPresent) {
	        	 System.out.println("\u001B[32m"+editServiceUserOptionPresent+"\u001B[0m");
	            System.out.println("\u001B[32m The ' " +val + " ' option is present. \u001B[0m");
	        } else {
	        	 System.out.println("\u001B[31m"+editServiceUserOptionPresent+"\u001B[0m");
	            System.out.println("\u001B[31mThe ' " +val + " ' option is not present. \u001B[0m");
	        }
		    }
	 	 public void popupwindowOk(String Value) throws InterruptedException
	 	    {
	 	    
	 	    		Wait.untilPageLoadComplete(driver);
	 	    		WebElement Yespop= driver.findElement(By.xpath("//*[contains(@class,'dynamic-form')]//span[text()='"+Value+"']"));
	 	    		//((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",Activebtn);
	 	    		try {
	 	    			util.actionMethodClick(driver, Yespop);
	 	  	   	    	}
	 	  	   	    	catch(Exception e)
	 	  	   	    	{
	 	  	   	    	util.actionMethodClick(driver, Yespop);
	 	  	   	    	}
	 	    		} 

		 public void NoDocumentnextaddress() throws InterruptedException
	 	    {
	 	    
	 	    		Wait.untilPageLoadComplete(driver);
	 	    		docnum= driver.findElement(By.xpath("//*[contains(@class,'mears-tab__count ng-star-inserted')]"));
	 	    		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",docnum);
	 	    		System.out.println("The number of document present : " +docnum.getText());
	 	    		documentCount = Integer.parseInt(docnum.getText());

	 	    }

		 public void NoDocumentunderFolders() throws InterruptedException
	 	    {
	 	    
	 	    		
	 	           try {
	 	        	  Wait.untilPageLoadComplete(driver);
		 	    		WebElement photoLink = driver.findElement(By.xpath("(//*[contains(@data-mat-icon-name,'minus_square')])[1]"));
		 	    		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",photoLink);
		 	            photoLink.click();
	 	           WebElement garFlueLink = driver.findElement(By.xpath("(//*[contains(@class,'mat-icon notranslate tree-view__expandable-icon mat-icon-no-color')])[2]"));
	 	          ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",garFlueLink);
	 	          
	 	          try {
	 	    			util.actionMethodClick(driver, garFlueLink);
	 	  	   	    	}
	 	  	   	    	catch(Exception e)
	 	  	   	    	{
	 	  	   	    	util.actionMethodClick(driver, garFlueLink);
	 	  	   	    	}
	 	      // If the element is found, you can perform actions on it
	 	            System.out.println("Element found: " + garFlueLink.getText());
	 	          } catch (NoSuchElementException e) {
	 	             // If the element is not found, handle the exception (in this case, just print a message)
	 	             System.out.println("Element not found");
	 	         }
	 	          	// Get the count of files 
	 	            int FileCount = getFileCount();
	 	            System.out.println("File count under Folders: " + FileCount);
	 	    }
		 private  int getFileCount() {
		        // Replace with the appropriate locator for file count
			    List<WebElement> icons =  driver.findElements(By.xpath("//*[@class='tree-view__leaf-icon']"));
		        iconCount = icons.size();
		        return iconCount;
		    }
		 public void ClickOnFolderUnderDocument(String val) throws InterruptedException
	 	    {
	 	           try {
	 	        	  Wait.untilPageLoadComplete(driver);
		 	    		WebElement tab = driver.findElement(By.xpath("//*[contains(@role,'tablist')]//*[contains(text(),'"+val+"')]"));
		 	    		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",tab);
		 	    		 try {
		 	    			tab.click();
			 	  	   	    	}
			 	  	   	    	catch(Exception e)
			 	  	   	    	{
			 	  	   	    	util.actionMethodClick(driver, tab);
			 	  	   	    	}
	 	          
	 	      // If the element is found, you can perform actions on it
	 	            System.out.println("Element found: " + tab.getText());
	 	          } catch (NoSuchElementException e) {
	 	             // If the element is not found, handle the exception (in this case, just print a message)
	 	             System.out.println("Element not found");
	 	         }
	 	          	// Get the count of files 
	 	         
	 	    }
		 public void ValidateCount() throws InterruptedException
	 	    {
			 System.out.println("Count next to Address is: "+documentCount);
			 System.out.println("Count of file present is: "+iconCount);
			 if (documentCount == iconCount) {
	                System.out.println("\u001B[32mValidation successful. Counts are equal.\u001B[0m");
	            } else {
	                System.out.println("\u001B[31mValidation failed. Counts are not equal.\u001B[0m");
	            }
	 	    		

	 	    } 
		 public void DownloadFile() throws InterruptedException
	 	    {
			 
			  WebElement icons =  driver.findElement(By.xpath("(//*[contains(@class,'mat-tree-node tree-view-link tree-view__node')])[1]"));		
			  System.out.println("The name of document : " +icons.getText());
			  String fileName = icons.getText();  // Replace with the actual file name
		         
			  try {
	    			util.actionMethodClick(driver, icons);
	  	   	    	}
	  	   	    	catch(Exception e)
	  	   	    	{
	  	   	    	util.actionMethodClick(driver, icons);
	  	   	    	}
			  WebElement downloadicon= driver.findElement(By.xpath("//*[contains(@class,'fa fa-download')]"));		
			  try {
	    			util.actionMethodClick(driver, downloadicon);
	  	   	    	}
	  	   	    	catch(Exception e)
	  	   	    	{
	  	   	    	util.actionMethodClick(driver, downloadicon);
	  	   	    	}
			  HashMap<String, Object> chromePrefs = new HashMap<>();
		        chromePrefs.put("download.default_directory", "C:/Users/neha.sain/Downloads");
		        ChromeOptions options = new ChromeOptions();
		        WebDriver driver = new ChromeDriver(options);
		        options.setExperimentalOption("prefs", chromePrefs);
		        File downloadedFile = new File("C:/Users/neha.sain/Downloads", fileName);
		         System.out.println("Download File" +downloadedFile);
		     // Create a new instance of the Chrome driver with the specified options
		        
			  if (downloadedFile.exists()) {
	                System.out.println("File downloaded successfully.");
	            } else {
	                System.out.println("File not found. Download may have failed.");
	            }

	 	    } 
		 public void SelectSiteSection() throws InterruptedException
		    {
		    	Thread.sleep(1000);
		    	WebElement section = driver.findElement(By.xpath("//*[@class='service-user-search-filter__select-input']//*[contains(text(),'- select a site -')]"));
		    	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", section);
		    	util.actionMethodClick(driver, section);
		    	
		    }

		public void SelectRelatedTab(String tabname) throws InterruptedException
			{
			Thread.sleep(1000);
		    Wait.untilPageLoadComplete(driver);
	        System.out.println(tabname);
	        try {
	        	objTabRelated.click();
	        } catch(Exception e)
	        {
	        	
	        }
	        ;
	        Thread.sleep(1000);
			}
		
		public void ClickRowUnderJobs() throws InterruptedException
		{
		
        Thread.sleep(1000);
        WebElement JobNo1 = driver.findElement(By.xpath("(//*[contains(@class,'mat-cell cdk-cell mears-table__cell cdk-column')])[1]"));
    	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", JobNo1);
    	util.actionMethodClick(driver, JobNo1);
		}
		
		public void ClickRequiredRowUnderJobs(String rowval) throws InterruptedException
		{
		
        Thread.sleep(1000);
        WebElement ClickRow = driver.findElement(By.xpath("//tr[contains(., '"+rowval+"')]"));
    	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", ClickRow);
    	util.actionMethodClick(driver, ClickRow);
		}
		
		
		public void SelectStatusTab(String tabname) throws InterruptedException
		{
		Thread.sleep(1000);
	    Wait.untilPageLoadComplete(driver);
        System.out.println(tabname);
        WebElement StatusTab = driver.findElement(By.xpath("//*[contains(@class,'mat-table cdk-table mat-sort mears-table')]//*[contains(text(),'0 - Entered')]"));
    	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", StatusTab);
        try {
        	StatusTab.click();
        } catch(Exception e)
        {
        	
        }
        ;
        Thread.sleep(1000);
		}
		public void ClickRowUnderJobs(String tabname) throws InterruptedException
		{
		
        Thread.sleep(1000);
        WebElement JobNo1 = driver.findElement(By.xpath("(//*[contains(@class,'mat-cell cdk-cell mears-table__cell cdk-column')])[1]"));
    	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", JobNo1);
    	util.actionMethodClick(driver, JobNo1);
		}
		
		public void RowUnderRiskTab(String field) 
		{
			List<WebElement> rows = driver.findElements(By.xpath("//*[@class='"+field+"']//*[@class='mat-row cdk-row mears-table__data-row mears-table__data-row--hover ng-star-inserted']"));
			 System.out.println("Row count:  "+rows.size());
			for (WebElement row : rows) {
				
	            // Get all cells in the current row
	            List<WebElement> cells = row.findElements(By.tagName("td"));
	            // Iterate through each cell in the row and extract cell value
	            for (WebElement cell : cells) {
	                String cellText = cell.getText();
	                System.out.print("\u001B[32m"+cellText+ "\t"+ "\u001B[0m" + "\t");
	            }
	            System.out.println(); // Move to the next line for the next row
	        }
		}
		public void RowUnderPopupTable() 
		{
			List<WebElement> Colrows = driver.findElements(By.xpath("//*[@class='mat-table cdk-table mat-sort mears-table rooms-dialog__table']//*[@role='columnheader']"));
			 System.out.println("Col count:  "+Colrows.size());
			for (WebElement row : Colrows) {
				 String cellText = row.getText();
	                System.out.print(cellText + "\t");
			}
			List<WebElement> rows = driver.findElements(By.xpath("//*[@class='mat-table cdk-table mat-sort mears-table rooms-dialog__table']//*[@class='mat-row cdk-row mears-table__data-row ng-star-inserted']"));
			 System.out.println("Row count:  "+rows.size());
			for (WebElement row : rows) {
				
	            // Get all cells in the current row
	            List<WebElement> cells = row.findElements(By.tagName("td"));
	            // Iterate through each cell in the row and extract cell value
	            for (WebElement cell : cells) {
	                String cellText = cell.getText();
	                System.out.print("\u001B[32m"+cellText+ "\t"+ "\u001B[0m" + "\t");
	            }
	            System.out.println(); // Move to the next line for the next row
	        }
			
		}
		public void ClickInactiveRiskchk() 
		{
			{
				try {
					Thread.sleep(2000);
					WebElement InactiveRiskChk=driver.findElement(By.xpath("//*[@class='mat-checkbox risks-list__checkbox mat-accent']//*[@class='mat-checkbox-inner-container']"));
					 util.actionMethodClick(driver, InactiveRiskChk);
				}catch(InterruptedException e)
				{
					e.printStackTrace();
				}}
		}
		public void ClickOnArrow(String arrowclass,String tabname) throws InterruptedException
		{
		Thread.sleep(1000);
	    Wait.untilPageLoadComplete(driver);
        System.out.println(tabname);
        WebElement Arrow = driver.findElement(By.xpath("//*[@class='"+arrowclass+"']//*[@data-mat-icon-name='"+tabname+"']"));
    	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", Arrow);
        try {
        	Arrow.click();
        } catch(Exception e)
        {
        	
        }
        ;
        Thread.sleep(1000);
		}
		}

    	
    	
    	

	
	

	


	
	
		


		
		
		
		 
		
		
	
	
