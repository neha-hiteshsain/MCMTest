package com.sat.Pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.github.javafaker.Faker;
import com.sat.testUtil.Testutil;
import com.sat.testUtil.Wait;
import com.sat.testbase.Assertions;


import io.cucumber.datatable.DataTable;



public class Mcm_AdminPage {
	private WebDriver driver;
	
	@FindBy(xpath = "//*[starts-with(@class,'mat-focus-indicator mears-form')]//*[contains(text(),'Find')]")
	private WebElement Findbtn;

	@FindBy(xpath = "//*[contains(@class,'siteholder')]//*[@id='SiteSelection']")
	private WebElement Sitelist;
	
	@FindBy(xpath = "//*[contains(@class,'menu-button__user-icon')]")
	private WebElement UserMenuIcon;
	
	@FindBy(xpath = "//*[@class='uasi-manage-user']")
	private WebElement SelectUserEmailId;
	
	WebElement Iconeditbtn;
	Testutil testutil = new Testutil();
	Wait waits = new Wait();
	Testutil util = new Testutil();
    Assertions assertion = new Assertions(driver);
    String randomEmail;
    String randomAccountNumber;
    String actualtext;
    Logger logger = Logger.getLogger(Mcm_AdminPage.class.getName());
	public Mcm_AdminPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public boolean isClickable(WebElement ele) {
		boolean flag = true;
		try {
			new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.elementToBeClickable(ele));
			System.out.println("Element is clickable");
		} catch (Exception e) {
			System.out.println("Element isn't clickable");
			flag = false;
		}
		return flag;
	}
	
	
     public void clickOnGeneratePassword()
     {
    	 Wait.untilPageLoadComplete(driver,400);
    	 WebElement generatepassword= driver.findElement(By.xpath("//button[contains(@class,'btn btn-info btn-sm generatepassword')]//*[contains(@class,'fa fa-magic')]"));
    		try {
    			new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.elementToBeClickable(generatepassword));
    			util.actionMethodClick(driver, generatepassword);
    			System.out.println("Element is clickable");
    		} catch (Exception e) {
    			System.out.println("Element isn't clickable");
    			
    			util.actionMethodClick(driver, generatepassword);
    			
    		}
     }

     public void GenerateRandomEmailId(String string)
     {
    	 Wait.untilPageLoadComplete(driver,400);
    	 Faker faker = new Faker();
    	 randomEmail =faker.internet().emailAddress();
    	 System.out.println("Random Email: " + randomEmail);
    	 driver.findElement(By.xpath("//*[@id='"+ string+"']")).sendKeys(Keys.CONTROL+"A");
	     driver.findElement(By.xpath("//*[@id='"+ string +"']")).sendKeys(randomEmail);
     }
     public void GenerateRandomAccountNumber(String AccNo)
     {
    	 Wait.untilPageLoadComplete(driver,400);
    	 Faker faker = new Faker();
    	 randomAccountNumber =faker.finance().bic();
    	 System.out.println("Random Account Number: " + randomAccountNumber);
    	 driver.findElement(By.xpath("//*[@id='"+ AccNo+"']")).sendKeys(Keys.CONTROL+"A");
	     driver.findElement(By.xpath("//*[@id='"+ AccNo +"']")).sendKeys(randomAccountNumber);
     }
     public void ClickUnderTabforSelectingVal(String ID,String string)
     {
    	 try {
				System.out.println("Under : " + string );
				WebElement txtval= driver.findElement(By.xpath("//*[@id='"+ ID+"']"));
				Wait.elementToBeClickable(driver, txtval, 3);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",txtval );
				System.out.println("Selected Value : " + txtval.getText() );
		    	 try {
		    	 Wait.elementToBeClickable(driver, txtval, 5);
		    	 util.actionMethodClick(driver, txtval);
		     }
		      catch (Exception e) {
					// TODO Auto-generated catch blockx
		    	  Wait.elementToBeClickable(driver, txtval, 5);
		    	  txtval.click();
					e.printStackTrace();
				}
			
     } catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
     } 
     public void SelectOptionUnderSites(String option)
     {
    	 try {
    	 util.actionMethodClick(driver, Sitelist);
     }
      catch (Exception e) {
			// TODO Auto-generated catch block
    	  util.actionMethodClick(driver, Sitelist);
			e.printStackTrace();
		}
    	 Select List_of_Sites =new Select(Sitelist);
    	 List_of_Sites.selectByVisibleText(option);
}
     public void ClickOnUserMenuIcon()
     {
    	 try {
    	 util.actionMethodClick(driver, UserMenuIcon);
     }
      catch (Exception e) {
			// TODO Auto-generated catch block
    	  util.actionMethodClick(driver, UserMenuIcon);
			e.printStackTrace();
		}
     }
    	 public void EnterRandomEmailId(String string)
         {
        	 Wait.untilPageLoadComplete(driver,400);
        	 driver.findElement(By.xpath("//*[@id='"+ string+"']")).sendKeys(Keys.CONTROL+"A");
    	     driver.findElement(By.xpath("//*[@id='"+ string +"']")).sendKeys(randomEmail);
         }
    	 public void UserSelectEmailDisplayed()
         {
    		 try {
    	    	 util.actionMethodClick(driver, SelectUserEmailId);
    	     }
    	      catch (Exception e) {
    				// TODO Auto-generated catch block
    	    	  util.actionMethodClick(driver, SelectUserEmailId);
    				e.printStackTrace();
    			}
         }	
    	 public void ValidateCorrectValueSelected(DataTable dataTable)
         {
    		 List<List<String>> actual = dataTable.cells();
 			List<String> expectedTexts = new ArrayList<>();
 			expectedTexts.addAll(actual.get(0));
 			 System.out.println(expectedTexts);
 		 for(String exptext:expectedTexts) {
 			WebElement element= driver.findElement(By.xpath("//*[contains(@id,'"+exptext+"')]//*[ contains(@class,'userstatustext')]"));
			 actualtext =driver.findElement(By.xpath("//*[contains(@id,'"+exptext+"')]")).getText();
			 System.out.println("Element ID : "+actualtext);
			 String classAttributeValue = element.getAttribute("class");
			 boolean isMarkedAsTrue = classAttributeValue.contains("true");
			 if (isMarkedAsTrue) {
	                System.out.println("\u001B[32m Element with ID " + exptext + " is marked as true.\u001B[0m");
	            } else {
	                System.out.println("\u001B[32m Element with ID " + exptext + " is not marked as true.\u001B[0m");
	            }
		 } 
         }

    	 public void UserClickUnderUserbtn(String value)
         {
    		 
 			WebElement userbtn= driver.findElement(By.xpath("//*[contains(@title,'"+value+"')]"));
 			Wait.elementToBeClickable(driver, userbtn, 3);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",userbtn );

 			 try {
    	    	 util.actionMethodClick(driver, userbtn);
    	     }
    	      catch (Exception e) {
    				// TODO Auto-generated catch block
    	    	  util.actionMethodClick(driver, userbtn);
    				e.printStackTrace();
    			}
         } 
    	 public void UserClickUnderUserbtnforClass(String value,String classname)
         {
    		 
 			WebElement userbtn= driver.findElement(By.xpath("//*[contains(@title,'"+value+"')]//*[contains(@class,'"+ classname+ "')]"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",userbtn );
			Actions actions = new Actions(driver);
			//actions.doubleClick(userbtn).perform();
			Wait.elementToBeClickable(driver, userbtn, 10);
			userbtn.click();
			Alert alert = driver.switchTo().alert();
			alert.accept();
         } 
    	 public void UserClickOnCopyUser()
         {
 			WebElement Copybtn= driver.findElement(By.xpath("//*[contains(@title,'Copy user')]//*[contains(@class,'fa fa-files-o')]"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",Copybtn );
			Wait.elementToBeClickable(driver, Copybtn, 10);
			Copybtn.click();
         } 
    	 public void verifyAlertField(String value)
    	 {
    		 WebElement actual=driver.findElement(By.xpath("//*[contains(@class,'"+value+"')]"));
    		 System.out.println("\u001B[32m"+actual.getText()+"\u001B[0m");
    		 Assert.assertTrue(actual.isDisplayed(), "Text is not displayed: " + actual.getText());
    	 }
    	 public void UserClickUnderSitesbtn(String value)
         {
    		 
 			WebElement sitebtn= driver.findElement(By.xpath("(//*[contains(@class,'"+value+"')])[1]"));
 			Wait.elementToBeClickable(driver, sitebtn, 3);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",sitebtn );

 			 try {
    	    	 util.actionMethodClick(driver, sitebtn);
    	     }
    	      catch (Exception e) {
    				// TODO Auto-generated catch block
    	    	  util.actionMethodClick(driver, sitebtn);
    				e.printStackTrace();
    			}
         } 
    	 public void UserClickUnderPropertyAllocation(String value)
         {
    		 
 			WebElement prodrop= driver.findElement(By.xpath("(//*[contains(@class,'"+value+"')])[2]"));
 			Wait.elementToBeClickable(driver, prodrop, 3);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",prodrop );

 			 try {
    	    	 util.actionMethodClick(driver, prodrop);
    	     }
    	      catch (Exception e) {
    				// TODO Auto-generated catch block
    	    	  util.actionMethodClick(driver, prodrop);
    				e.printStackTrace();
    			}
         } 
    	 public void UserClickUnderTab(String value)
         {
    		 try {
 			WebElement siterow= driver.findElement(By.xpath("//*[contains(@class,'"+value+"')]//*[contains(@class,'mat-row cdk-row mears')]"));
 			Wait.elementToBeClickable(driver, siterow, 3);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",siterow );

 			 try {
    	    	 util.actionMethodClick(driver, siterow);
    	     }
    	      catch (Exception e) {
    				// TODO Auto-generated catch block
    	    	  util.actionMethodClick(driver, siterow);
    			}
    		 
         } catch (org.openqa.selenium.NoSuchElementException e) {
             // Log the error if siterow element is not found
        	 WebElement siterow= driver.findElement(By.xpath("//*[@class='previous-work-panel__wrapper']//*[text()='-- No Active Work Orders --']"));
        	 System.out.println("\u001B[32m "+siterow.getText() + "\u001B[0m");
        	 logger.log(Level.SEVERE, "No row present under tab", e);
         }
         } 
    	 public void UserClickContractUnderSite() throws InterruptedException
         {
    		 
 			WebElement Contractbtn= driver.findElement(By.xpath("(//*[contains(@class,'sitecontractitem')])[1]"));
 			Wait.elementToBeClickable(driver, Contractbtn, 3);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",Contractbtn );
			// Check if the element is initially present
			try {
    	    	 util.actionMethodClick(driver, Contractbtn);
    	     }
    	      catch (Exception e) {
    				// TODO Auto-generated catch block
    	    	  util.actionMethodClick(driver,Contractbtn);
    				e.printStackTrace();
    			}

         }
    	 public void UserValidateContract()
    	 {
    		 WebElement contractBtn= driver.findElement(By.xpath("(//*[contains(@class,'sitecontractitem')])[1]")); 
             if (contractBtn.getAttribute("class").contains("add")) {
                 System.out.println("\u001B[32mContract is Removed.\u001B[0m");

             } else {
                 System.out.println("\u001B[32mContract is not removed.\u001B[0m");
             }
    	 }
    	 public void UserValidateCompletRequestFieldDisplay()
    	 {
    		 WebElement Completion_Date=  driver.findElement(By.xpath("//*[contains(@data-placeholder,'Completion Date')]"));
    		 WebElement Completed_By =driver.findElement(By.xpath("//*[contains(@data-placeholder,'Completed By')]"));
             WebElement Reason_notes = driver.findElement(By.xpath("//*[contains(@id,'reasonNotes')]"));
             System.out.println("\u001B[32mCompletion Date: .\u001B[0m "+Completion_Date.getAttribute("value"));
             System.out.println("\u001B[32mCompleted By: .\u001B[0m "+Completed_By.getAttribute("value"));
             System.out.println("\u001B[32mReason notes: .\u001B[0m "+Reason_notes.getAttribute("value"));
}
}





    	
    	
    	

	
	

	


	
	
		


		
		
		
		 
		
		
	
	
