package com.sat.Pages;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.sat.testUtil.Testutil;
import com.sat.testUtil.Wait;
import com.sat.testbase.Assertions;



public class SupervisorPage {
	private WebDriver driver;
	
	@FindBy(xpath = "//*[starts-with(@class,'mat-focus-indicator mears-form')]//*[contains(text(),'Find')]")
	private WebElement ObjTab;

	@FindBy(xpath = "//*[contains(@class,'siteholder')]//*[@id='SiteSelection']")
	private WebElement Sitelist;
	
	@FindBy(xpath = "//*[contains(@class,'menu-button__user-icon')]")
	private WebElement UserMenuIcon;
	
	@FindBy(xpath = "//*[@class='uasi-manage-user']")
	private WebElement SelectUserEmailId;
	
	WebElement Iconeditbtn;
	Testutil testutil = new Testutil();
	Wait waits = new Wait();
	Testutil util = new Testutil();
    Assertions assertion = new Assertions(driver);
    
    List<WebElement> RowCountBefore;
    List<WebElement> RowCountAfter;
    int BeforeCount;
    int AfterCount;
    private static final Logger logger = Logger.getLogger(SupervisorPage.class.getName());
    
	public SupervisorPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public boolean isClickable(WebElement ele) {
		boolean flag = true;
		try {
			new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.elementToBeClickable(ele));
			System.out.println("Element is clickable");
		} catch (Exception e) {
			System.out.println("Element isn't clickable");
			flag = false;
		}
		return flag;
	}
	public void clickRelatedTab(String tabname) throws InterruptedException
	{
		Thread.sleep(2000);
		Wait.untilPageLoadComplete(driver);
		System.out.println(tabname);
		WebElement Tabname = driver.findElement(By.xpath("//*[@class='address-menu__container']//*[contains(text(),'"+tabname+"')]"));
		try {
			util.actionMethodClick(driver, Tabname);
		}catch(Exception e)
		{
			Tabname.click();
		}
	}
	public void UserClickDropdownUnderStatus(String dropdownval)
	{
		try {
			Thread.sleep(1000);
		   Actions actions= new Actions(driver);
		   actions.click(driver.findElement(By.xpath("//*[@valuefieldname='"+dropdownval+"']"))).build().perform();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public boolean fieldExistorNot(String fieldName)
	{

	    try {
	    	WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(120));
	    	WebElement element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'" + fieldName + "')]")));
	    	boolean isDisplayed = element.isDisplayed();
            if (!isDisplayed) {
                logger.severe("Error: Element with text '" + fieldName + "' is not displayed.");
            }
            return isDisplayed;
        } catch (Exception e) {
            logger.severe("Exception occurred: " + e.getMessage());
            return false;
        }
	}
	
	public void ClickOnIcon(String Icon)
	{
		try {
			Thread.sleep(2000);
			WebElement Iconbtn=driver.findElement(By.xpath("(//*[@data-mat-icon-name='"+Icon+"'])[1]"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",Iconbtn);
			 util.actionMethodClick(driver, Iconbtn);
		}catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		
	}
	public void ClickOnSORItem()
	{
		try {
			Thread.sleep(2000);
			WebElement plusIcon=driver.findElement(By.xpath("(//*[contains(@class,'mcmview-flex-container select-sor-line__container')]//*[contains(@class,'mat-cell cdk-cell mears-table__cell cdk-column-scheduleCode mat-column-scheduleCode ng-star-inserted')])[1]"));
			 util.actionMethodClick(driver, plusIcon);
		}catch(InterruptedException e)
		{
			e.printStackTrace();
		}}
	
	public void UserValidateAddScheduleLineFieldDisplay()
	 {
		 WebElement Quantity=  driver.findElement(By.xpath("//*[contains(@data-placeholder,'Quantity')]"));
		 WebElement Adjustment =driver.findElement(By.xpath("//*[contains(@data-placeholder,'Adjustment')]"));
        WebElement Total = driver.findElement(By.xpath("//*[contains(@data-placeholder,'Total')]"));
        WebElement Completed = driver.findElement(By.xpath("//*[contains(@data-placeholder,'Completed')]"));
        System.out.println("\u001B[32mQuantity: .\u001B[0m "+Quantity.getAttribute("value"));
        System.out.println("\u001B[32mAdjustment: .\u001B[0m "+Adjustment.getAttribute("value"));
        System.out.println("\u001B[32mTotal: .\u001B[0m "+Total.getAttribute("value"));
        System.out.println("\u001B[32mCompleted: .\u001B[0m "+Completed.getAttribute("value"));
}
	public void ValidateRowCountBefore() throws InterruptedException {
	 	
	 		RowCountBefore = driver.findElements(By.xpath("//*[@class='edit-job-schedule-lines-list-container ng-star-inserted']//*[ contains(@class,'mat-row cdk-row mears-table__data-row mears-table__data-row--hover ng-star-inserted')]"));
	 		System.out.println("\u001B[32mNumber of Row present in Table : .\u001B[0m"+RowCountBefore.size());
	 		   BeforeCount =RowCountBefore.size();
	 		  
	 		}
	public void ValidateRowCountAfter() throws InterruptedException {
	 	
		RowCountAfter = driver.findElements(By.xpath("//*[@class='edit-job-schedule-lines-list-container ng-star-inserted']//*[ contains(@class,'mat-row cdk-row mears-table__data-row mears-table__data-row--hover ng-star-inserted')]"));
 		System.out.println("\u001B[32mNumber of Row present in Table : .\u001B[0m"+RowCountAfter.size());
 		 AfterCount=RowCountAfter.size();
 		if(AfterCount>BeforeCount)
 		{
 			System.out.println("\u001B[32mTable row count increased after adding a schedule line.\u001B[0m");
 		}
 		else {
 			System.out.println("\u001B[32mTable row count did not increased after adding a schedule line.\u001B[0m");
 		}
 		}
public void SelectLastRowForm() throws InterruptedException {
	 	
		WebElement CurrentRow = driver.findElement(By.xpath("(.//tr[last()])[1]"));
 		System.out.println("\u001B[32mContent of last row in Table : .\u001B[0m"+CurrentRow.getText());
 		CurrentRow.click();
 		
 		}
public void ClickJobNoDomesticFire() throws InterruptedException {
 	
	WebElement CurrentRow = driver.findElement(By.xpath("(//*[@class='table formlisttable']//*[contains(text(),'P431245')])[3]"));
		System.out.println("\u001B[32mContent of last row in Table : .\u001B[0m"+CurrentRow.getText());
		CurrentRow.click();
		
		}
public void ClickJobNoEIVR() throws InterruptedException {
 	
	WebElement CurrentRow = driver.findElement(By.xpath("(//*[@class='table formlisttable']//*[contains(text(),'P431338')])[2]"));
		System.out.println("\u001B[32mContent of last row in Table : .\u001B[0m"+CurrentRow.getText());
		CurrentRow.click();
		
		}
public void ClickJobNoEIC() throws InterruptedException {
 	
	WebElement CurrentRow = driver.findElement(By.xpath("(//*[@class='table formlisttable']//*[contains(text(),'P431262')])[1]"));
		System.out.println("\u001B[32mContent of last row in Table : .\u001B[0m"+CurrentRow.getText());
		CurrentRow.click();
		}
public void ClickJobNoEICR() throws InterruptedException {
 	
	WebElement CurrentRow = driver.findElement(By.xpath("(//*[@class='table formlisttable']//*[contains(text(),'P431262')])[3]"));
		System.out.println("\u001B[32mContent of last row in Table : .\u001B[0m"+CurrentRow.getText());
		CurrentRow.click();
		
		}
public void ClickJobNoAll(String JobNo) throws InterruptedException {
 	
	WebElement CurrentRow = driver.findElement(By.xpath("(//*[@class='table formlisttable']//*[contains(text(),'"+JobNo+"')])[1]"));
		System.out.println("\u001B[32mContent of last row in Table : .\u001B[0m"+CurrentRow.getText());
		CurrentRow.click();
		}
public void FillReviewNoteInForm()
{
	try {
		Thread.sleep(2000);
		WebElement Formbtn=driver.findElement(By.xpath("//*[@class='form-group has-feedback formio-component formio-component-textarea formio-component-F_ReviewNote']//*[@class='form-control']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",Formbtn);
		 //util.actionMethodClick(driver, Formbtn);
		 Formbtn.click();
		/// Formbtn.sendKeys(Keys.CONTROL+"A");
		 Formbtn.sendKeys("Demo for review test");
	}catch(InterruptedException e)
	{
		e.printStackTrace();
	}}
public void ClickOnBtnInForm(String name)
{
	try {
		Thread.sleep(2000);
		WebElement Formbtn=driver.findElement(By.xpath("//*[@name='"+name+"']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",Formbtn);
		 //util.actionMethodClick(driver, Formbtn);
		 Formbtn.click();
		 Alert alert = driver.switchTo().alert();
		alert.accept();
	}catch(InterruptedException e)
	{
		e.printStackTrace();
	}}
public void ClickOnTablistInForm(String name)
{
	try {
		Thread.sleep(2000);
		WebElement Tablist=driver.findElement(By.xpath("//*[@class='nav nav-tabs card-header-tabs nav-tabs-vertical']//*[contains(text(),'"+name+"')]"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",Tablist);
		 util.actionMethodClick(driver, Tablist);
		//Tablist.click();
	}catch(InterruptedException e)
	{
		e.printStackTrace();
	}}
public void ClickOnDeclaartionChkbox()
{
	try {
		Thread.sleep(2000);
		WebElement Chkboxform=driver.findElement(By.xpath("//*[@class='form-group has-feedback formio-component formio-component-checkbox formio-component-F_DeclarationCheck  required']//*[@class='form-check-input']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",Chkboxform);
		 util.actionMethodClick(driver, Chkboxform);
		//Tablist.click();
	}catch(InterruptedException e)
	{
		e.printStackTrace();
	}}
public void FillNoteInForm(String val,String name)
{
	try {
		Thread.sleep(2000);
		WebElement Formbtn=driver.findElement(By.xpath("//*[@name='"+name+"']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",Formbtn);
		 //util.actionMethodClick(driver, Formbtn);
		 Formbtn.click();
		/// Formbtn.sendKeys(Keys.CONTROL+"A");
		 Formbtn.sendKeys(val);
	}catch(InterruptedException e)
	{
		e.printStackTrace();
	}}
	public void ClickOnChkBoxCustomerVisible()
	{
		try {
			Thread.sleep(2000);
			WebElement CustomerChk=driver.findElement(By.xpath("//*[contains(@class,'job-documents')]//*[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin']"));
			 util.actionMethodClick(driver, CustomerChk);
		}catch(InterruptedException e)
		{
			e.printStackTrace();
		}}
	public void ClickOnTabUnderJobs(String Tabname)
	{
		try {
			Thread.sleep(2000);
			WebElement ClickTab=driver.findElement(By.xpath("//*[contains(@title,'Jobs')]//*[contains(text(),'"+Tabname+"')]"));
			 util.actionMethodClick(driver, ClickTab);
		}catch(InterruptedException e)
		{
			e.printStackTrace();
		}}
	public void ClickOnBookIconUnderDate()
	{
		try {
			Thread.sleep(2000);
			WebElement ClickBookIcon=driver.findElement(By.xpath("(//*[@aria-label='book icon'])[2]"));
			 util.actionMethodClick(driver, ClickBookIcon);
		}catch(InterruptedException e)
		{
			e.printStackTrace();
		}}
	public void ClickOnPlusIconUnderFolder(String foldername)
	{
		try {
			Thread.sleep(2000);
			WebElement ClickPlusIcon=driver.findElement(By.xpath("//*[contains(text(),'"+foldername+"')]//*[@data-mat-icon-name='minus_square']"));
			 util.actionMethodClick(driver, ClickPlusIcon);
		}catch(InterruptedException e)
		{
			e.printStackTrace();
		}}
	public void ClickOnFileUnderFolder(String num,String foldername) throws IOException, InterruptedException
	{
		
	 WebElement icons =  driver.findElement(By.xpath("//mat-nested-tree-node["+num+"]//li[1]//ul[1]//mat-tree-node[1]/li[1]"));		
	  System.out.println("The name of document : " +icons.getText());
	 // String folderName = icons.getText();  // Replace with the actual file name
        
	  try {
			util.actionMethodClick(driver, icons);
	   	    	}
	   	    	catch(Exception e)
	   	    	{
	   	    	util.actionMethodClick(driver, icons);
	   	    	}
	Thread.sleep(4000);
	WebElement downloadicon= driver.findElement(By.xpath("//*[contains(@class,'fa fa-download')]"));	
	   ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",downloadicon);
	
	    try {
	    	new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.elementToBeClickable(downloadicon));
			util.actionMethodClick(driver, downloadicon);
	   	    	}
	   	    	catch(Exception e)
	   	    	{
	   	    //util.actionMethodClick(driver, downloadicon);
	   	    //	 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",downloadicon);
	   	    		util.actionMethodClick(driver, downloadicon);
	   	    	}
	    Thread.sleep(4000);
		Wait.untilPageLoadComplete(driver);
	  Testutil.takeScreenshot(driver);
	// testutil.switchToTabs(driver);
	  
	/*
	  HashMap<String, Object> chromePrefs = new HashMap<>();
       chromePrefs.put("download.default_directory", "C:/Users/neha.sain/Downloads");
       ChromeOptions options = new ChromeOptions();
       WebDriver driver = new ChromeDriver(options);
       options.setExperimentalOption("prefs", chromePrefs);
       File downloadedFile = new File("C:/Users/neha.sain/Downloads", "Room 1, 30, York Road, Hartlepool, Durham, United Kingdom, TS26 8AW_EICR18_2860001_NIRE115119_20240301_114542");
        System.out.println("Download File" +downloadedFile);
    // Create a new instance of the Chrome driver with the specified options
       
	  if (downloadedFile.exists()) {
           System.out.println("File downloaded successfully.");
       } else {
           System.out.println("File not found. Download may have failed.");
       }
	 */
	}
	
	
    }
	 	





    	
    	
    	

	
	

	


	
	
		


		
		
		
		 
		
		
	
	
